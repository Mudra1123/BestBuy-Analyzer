import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    // Seed Categories
    const categories = [
      { name: "Clothing", slug: "clothing", icon: "ri-t-shirt-line" },
      { name: "Electronics", slug: "electronics", icon: "ri-smartphone-line" },
      { name: "Home", slug: "home", icon: "ri-home-line" },
      { name: "Footwear", slug: "footwear", icon: "ri-footprint-line" },
      { name: "Computers", slug: "computers", icon: "ri-computer-line" },
      { name: "Gaming", slug: "gaming", icon: "ri-gamepad-line" },
    ];

    for (const category of categories) {
      const existingCategory = await db.query.categories.findFirst({
        where: (table, { eq }) => eq(table.slug, category.slug),
      });

      if (!existingCategory) {
        await db.insert(schema.categories).values(category);
        console.log(`Category ${category.name} created`);
      } else {
        console.log(`Category ${category.name} already exists`);
      }
    }

    // Seed Brands
    const brands = [
      // Clothing Brands
      { name: "Levi's", slug: "levis" },
      { name: "H&M", slug: "hm" },
      { name: "Zara", slug: "zara" },
      { name: "Nike", slug: "nike" },
      { name: "Adidas", slug: "adidas" },
      { name: "Calvin Klein", slug: "calvin-klein" },
      { name: "Puma", slug: "puma" },
      { name: "Gap", slug: "gap" },
      { name: "Tommy Hilfiger", slug: "tommy-hilfiger" },
      { name: "Ralph Lauren", slug: "ralph-lauren" },
      { name: "Under Armour", slug: "under-armour" },
      { name: "Gucci", slug: "gucci" },
      
      // Electronics Brands
      { name: "Apple", slug: "apple" },
      { name: "Samsung", slug: "samsung" },
      { name: "Google", slug: "google" },
      { name: "Sony", slug: "sony" },
      { name: "LG", slug: "lg" },
      { name: "Xiaomi", slug: "xiaomi" },
      { name: "OnePlus", slug: "oneplus" },
      { name: "Huawei", slug: "huawei" },
      { name: "Fitbit", slug: "fitbit" },
      { name: "Garmin", slug: "garmin" },
    ];

    for (const brand of brands) {
      const existingBrand = await db.query.brands.findFirst({
        where: (table, { eq }) => eq(table.slug, brand.slug),
      });

      if (!existingBrand) {
        await db.insert(schema.brands).values(brand);
        console.log(`Brand ${brand.name} created`);
      } else {
        console.log(`Brand ${brand.name} already exists`);
      }
    }

    // Seed Genders
    const genders = [
      { name: "Men", slug: "men" },
      { name: "Women", slug: "women" },
      { name: "Unisex", slug: "unisex" },
    ];

    for (const gender of genders) {
      const existingGender = await db.query.genders.findFirst({
        where: (table, { eq }) => eq(table.slug, gender.slug),
      });

      if (!existingGender) {
        await db.insert(schema.genders).values(gender);
        console.log(`Gender ${gender.name} created`);
      } else {
        console.log(`Gender ${gender.name} already exists`);
      }
    }

    // Seed Sizes
    const sizes = [
      { name: "XS" },
      { name: "S" },
      { name: "M" },
      { name: "L" },
      { name: "XL" },
      { name: "XXL" },
    ];

    for (const size of sizes) {
      const existingSize = await db.query.sizes.findFirst({
        where: (table, { eq }) => eq(table.name, size.name),
      });

      if (!existingSize) {
        await db.insert(schema.sizes).values(size);
        console.log(`Size ${size.name} created`);
      } else {
        console.log(`Size ${size.name} already exists`);
      }
    }

    // Seed Platforms with comprehensive metrics
    const platforms = [
      { 
        name: "Amazon", 
        slug: "amazon", 
        logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/320px-Amazon_logo.svg.png",
        colorCode: "#FF9900",
        deliveryTimeMin: 1,
        deliveryTimeMax: 3,
        shippingCost: "0.00",
        returnPolicyDays: 30,
        returnPolicyRating: "4.5",
        customerServiceRating: "4.2"
      },
      { 
        name: "Flipkart", 
        slug: "flipkart", 
        logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Flipkart_logo.svg/320px-Flipkart_logo.svg.png",
        colorCode: "#2874f0",
        deliveryTimeMin: 2,
        deliveryTimeMax: 5,
        shippingCost: "40.00",
        returnPolicyDays: 10,
        returnPolicyRating: "4.0",
        customerServiceRating: "3.8"
      },
      { 
        name: "Myntra", 
        slug: "myntra", 
        logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Myntra_logo.png/320px-Myntra_logo.png",
        colorCode: "#ff3f6c",
        deliveryTimeMin: 3,
        deliveryTimeMax: 7,
        shippingCost: "0.00",
        returnPolicyDays: 14,
        returnPolicyRating: "4.1",
        customerServiceRating: "3.9"
      },
    ];

    for (const platform of platforms) {
      const existingPlatform = await db.query.platforms.findFirst({
        where: (table, { eq }) => eq(table.slug, platform.slug),
      });

      if (!existingPlatform) {
        await db.insert(schema.platforms).values(platform);
        console.log(`Platform ${platform.name} created`);
      } else {
        console.log(`Platform ${platform.name} already exists`);
      }
    }

    // Get categories, brands, genders
    const clothingCategory = await db.query.categories.findFirst({
      where: (table, { eq }) => eq(table.slug, "clothing"),
    });
    const footwearCategory = await db.query.categories.findFirst({
      where: (table, { eq }) => eq(table.slug, "footwear"),
    });
    const electronicsCategory = await db.query.categories.findFirst({
      where: (table, { eq }) => eq(table.slug, "electronics"),
    });
    const computersCategory = await db.query.categories.findFirst({
      where: (table, { eq }) => eq(table.slug, "computers"),
    });

    // Clothing brands
    const levisBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "levis"),
    });
    const hmBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "hm"),
    });
    const nikeBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "nike"),
    });
    const adidasBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "adidas"),
    });
    const zaraBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "zara"),
    });
    const calvinKleinBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "calvin-klein"),
    });
    
    // Electronics brands
    const appleBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "apple"),
    });
    const samsungBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "samsung"),
    });
    const googleBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "google"),
    });
    const sonyBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "sony"),
    });
    const xiaomiBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "xiaomi"),
    });
    const oneplusBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "oneplus"),
    });
    const fitbitBrand = await db.query.brands.findFirst({
      where: (table, { eq }) => eq(table.slug, "fitbit"),
    });

    const menGender = await db.query.genders.findFirst({
      where: (table, { eq }) => eq(table.slug, "men"),
    });
    const unisexGender = await db.query.genders.findFirst({
      where: (table, { eq }) => eq(table.slug, "unisex"),
    });

    // Get platforms
    const amazonPlatform = await db.query.platforms.findFirst({
      where: (table, { eq }) => eq(table.slug, "amazon"),
    });
    const flipkartPlatform = await db.query.platforms.findFirst({
      where: (table, { eq }) => eq(table.slug, "flipkart"),
    });
    const myntraPlatform = await db.query.platforms.findFirst({
      where: (table, { eq }) => eq(table.slug, "myntra"),
    });

    // Only proceed if all references exist
    if (clothingCategory && electronicsCategory && computersCategory && footwearCategory && 
        levisBrand && hmBrand && nikeBrand && adidasBrand && zaraBrand && calvinKleinBrand && 
        appleBrand && samsungBrand && googleBrand && sonyBrand && xiaomiBrand && oneplusBrand && fitbitBrand &&
        menGender && unisexGender && amazonPlatform && flipkartPlatform && myntraPlatform) {
      
      // Seed Products
      const clothingProducts = [
        {
          name: "Levi's 511 Slim Fit Jeans",
          slug: "levis-511-slim-fit-jeans",
          description: "Classic slim fit jeans from Levi's",
          imageUrl: "https://images.unsplash.com/photo-1578587018452-892bacefd3f2",
          rating: 4.5,
          reviewCount: 432,
          categoryId: clothingCategory.id,
          brandId: levisBrand.id,
          genderId: menGender.id,
        },
        {
          name: "H&M Slim Fit Shirt",
          slug: "hm-slim-fit-shirt",
          description: "Slim fit shirt from H&M",
          imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab",
          rating: 4.0,
          reviewCount: 187,
          categoryId: clothingCategory.id,
          brandId: hmBrand.id,
          genderId: menGender.id,
        },
        {
          name: "Nike Dri-Fit T-Shirt",
          slug: "nike-dri-fit-tshirt",
          description: "Moisture-wicking t-shirt from Nike",
          imageUrl: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a",
          rating: 4.5,
          reviewCount: 532,
          categoryId: clothingCategory.id,
          brandId: nikeBrand.id,
          genderId: menGender.id,
        },
        {
          name: "Adidas Originals T-Shirt",
          slug: "adidas-originals-tshirt",
          description: "Classic t-shirt from Adidas",
          imageUrl: "https://images.unsplash.com/photo-1594938291221-94f18cbb5660",
          rating: 3.5,
          reviewCount: 287,
          categoryId: clothingCategory.id,
          brandId: adidasBrand.id,
          genderId: menGender.id,
        },
        {
          name: "Zara Premium Shirt",
          slug: "zara-premium-shirt",
          description: "Premium formal shirt from Zara",
          imageUrl: "https://images.unsplash.com/photo-1598522325074-042db73aa4e6",
          rating: 4.0,
          reviewCount: 156,
          categoryId: clothingCategory.id,
          brandId: zaraBrand.id,
          genderId: menGender.id,
        },
        {
          name: "Calvin Klein Casual Shirt",
          slug: "calvin-klein-casual-shirt",
          description: "Casual shirt from Calvin Klein",
          imageUrl: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8",
          rating: 3.5,
          reviewCount: 89,
          categoryId: clothingCategory.id,
          brandId: calvinKleinBrand.id,
          genderId: menGender.id,
        },
        {
          name: "Nike Air Max 270",
          slug: "nike-air-max-270",
          description: "Comfortable athletic shoes from Nike",
          imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
          rating: 4.5,
          reviewCount: 320,
          categoryId: footwearCategory.id,
          brandId: nikeBrand.id,
          genderId: menGender.id,
        },
      ];
      
      // Electronics products
      const electronicsProducts = [
        {
          name: "iPhone 15 Pro",
          slug: "iphone-15-pro",
          description: "Latest flagship smartphone from Apple with A17 Pro chip",
          imageUrl: "https://images.unsplash.com/photo-1678652197831-2d180705cd2c",
          rating: 4.8,
          reviewCount: 986,
          categoryId: electronicsCategory.id,
          brandId: appleBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "Samsung Galaxy S24 Ultra",
          slug: "samsung-galaxy-s24-ultra",
          description: "Samsung's premium flagship smartphone with advanced camera system",
          imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c",
          rating: 4.7,
          reviewCount: 827,
          categoryId: electronicsCategory.id,
          brandId: samsungBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "Google Pixel 8 Pro",
          slug: "google-pixel-8-pro",
          description: "Google's flagship smartphone with exceptional camera and AI features",
          imageUrl: "https://images.unsplash.com/photo-1678911034048-cc5a6605b1b9",
          rating: 4.6,
          reviewCount: 675,
          categoryId: electronicsCategory.id,
          brandId: googleBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "OnePlus 12",
          slug: "oneplus-12",
          description: "OnePlus flagship with Snapdragon 8 Gen 3 and Hasselblad cameras",
          imageUrl: "https://images.unsplash.com/photo-1676455891821-479d61bec6d1",
          rating: 4.5,
          reviewCount: 542,
          categoryId: electronicsCategory.id,
          brandId: oneplusBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "Apple Watch Series 9",
          slug: "apple-watch-series-9",
          description: "Latest smartwatch from Apple with health and fitness features",
          imageUrl: "https://images.unsplash.com/photo-1577899503278-a4639c986fef",
          rating: 4.7,
          reviewCount: 732,
          categoryId: electronicsCategory.id,
          brandId: appleBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "Samsung Galaxy Watch 6",
          slug: "samsung-galaxy-watch-6",
          description: "Advanced health tracking smartwatch from Samsung",
          imageUrl: "https://images.unsplash.com/photo-1600086827875-a63b01f1335c",
          rating: 4.5,
          reviewCount: 456,
          categoryId: electronicsCategory.id,
          brandId: samsungBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "Fitbit Sense 2",
          slug: "fitbit-sense-2",
          description: "Advanced health smartwatch with stress management features",
          imageUrl: "https://images.unsplash.com/photo-1636653683119-1ed389b13857",
          rating: 4.3,
          reviewCount: 389,
          categoryId: electronicsCategory.id,
          brandId: fitbitBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "Sony WH-1000XM5",
          slug: "sony-wh-1000xm5",
          description: "Premium noise-cancelling headphones with exceptional sound quality",
          imageUrl: "https://images.unsplash.com/photo-1578319439584-104c94d37305",
          rating: 4.9,
          reviewCount: 842,
          categoryId: electronicsCategory.id,
          brandId: sonyBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "iPad Pro 12.9-inch",
          slug: "ipad-pro-12-9",
          description: "Apple's most powerful tablet with M2 chip and Liquid Retina XDR display",
          imageUrl: "https://images.unsplash.com/photo-1589739900735-8e8d7b3e3b48",
          rating: 4.8,
          reviewCount: 723,
          categoryId: computersCategory.id,
          brandId: appleBrand.id,
          genderId: unisexGender.id,
        },
        {
          name: "MacBook Pro 16-inch",
          slug: "macbook-pro-16",
          description: "Powerful laptop for professionals with M3 Pro/Max chip",
          imageUrl: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9",
          rating: 4.7,
          reviewCount: 689,
          categoryId: computersCategory.id,
          brandId: appleBrand.id,
          genderId: unisexGender.id,
        },
      ];
      
      // Combine all products
      const products = [...clothingProducts, ...electronicsProducts];

      for (const product of products) {
        const existingProduct = await db.query.products.findFirst({
          where: (table, { eq }) => eq(table.slug, product.slug),
        });

        if (!existingProduct) {
          const [insertedProduct] = await db.insert(schema.products).values([product]).returning();
          console.log(`Product ${product.name} created`);

          // Associate with sizes
          const allSizes = await db.query.sizes.findMany();
          for (const size of allSizes) {
            await db.insert(schema.productSizes).values({
              productId: insertedProduct.id,
              sizeId: size.id,
            });
          }

          // Add prices for each platform
          let prices = [];
          
          // Electronics pricing
          if (product.categoryId === electronicsCategory?.id || product.categoryId === computersCategory?.id) {
            const basePrice = 
              product.name.includes("iPhone") ? 129999 :
              product.name.includes("Samsung Galaxy S24") ? 124999 :
              product.name.includes("Google Pixel") ? 89999 :
              product.name.includes("OnePlus") ? 69999 :
              product.name.includes("Apple Watch") ? 39999 :
              product.name.includes("Galaxy Watch") ? 29999 :
              product.name.includes("Fitbit") ? 24999 :
              product.name.includes("Sony WH") ? 29999 :
              product.name.includes("iPad") ? 109999 :
              product.name.includes("MacBook") ? 199999 :
              12999;
            
            prices = [
              {
                productId: insertedProduct.id,
                platformId: amazonPlatform.id,
                amount: basePrice,
                url: "#",
                isAvailable: true,
              },
              {
                productId: insertedProduct.id,
                platformId: flipkartPlatform.id,
                amount: Math.round(basePrice * 0.98), // 2% lower
                url: "#",
                isAvailable: true,
              },
              {
                productId: insertedProduct.id,
                platformId: myntraPlatform.id,
                amount: Math.round(basePrice * 1.02), // 2% higher
                url: "#",
                isAvailable: product.categoryId === electronicsCategory?.id, // Not all electronics available on Myntra
              }
            ];
          } 
          // Clothing pricing
          else {
            prices = [
              {
                productId: insertedProduct.id,
                platformId: amazonPlatform.id,
                amount: product.name.includes("Nike Air Max") ? 7495 : 
                       product.name.includes("Levi's") ? 2999 : 
                       product.name.includes("H&M") ? 1699 : 
                       product.name.includes("Nike Dri-Fit") ? 1499 : 
                       product.name.includes("Adidas") ? 1299 : 
                       product.name.includes("Zara") ? 2399 : 
                       3999,
                url: "#",
                isAvailable: true,
              },
              {
                productId: insertedProduct.id,
                platformId: flipkartPlatform.id,
                amount: product.name.includes("Nike Air Max") ? 7695 : 
                       product.name.includes("Levi's") ? 3199 : 
                       product.name.includes("H&M") ? 1499 : 
                       product.name.includes("Nike Dri-Fit") ? 1299 : 
                       product.name.includes("Adidas") ? 1399 : 
                       product.name.includes("Zara") ? 2499 : 
                       3599,
                url: "#",
                isAvailable: true,
              },
              {
                productId: insertedProduct.id,
                platformId: myntraPlatform.id,
                amount: product.name.includes("Nike Air Max") ? 7999 : 
                       product.name.includes("Levi's") ? 3499 : 
                       product.name.includes("H&M") ? 1599 : 
                       product.name.includes("Nike Dri-Fit") ? 1399 : 
                       product.name.includes("Adidas") ? 1449 : 
                       product.name.includes("Zara") ? 2299 : 
                       3699,
                url: "#",
                isAvailable: true,
              },
            ];
          }
          
          const productPrices = prices;

          await db.insert(schema.prices).values(productPrices);
          console.log(`Prices for ${product.name} created`);
          
          // Add platform reviews for each platform
          const platformReviews = [
            {
              productId: insertedProduct.id,
              platformId: amazonPlatform.id,
              averageRating: "4.5",
              totalReviews: Math.floor(Math.random() * 1000) + 100,
              qualityRating: "4.3",
              valueForMoneyRating: "4.1",
              deliveryExperienceRating: "4.7",
            },
            {
              productId: insertedProduct.id,
              platformId: flipkartPlatform.id,
              averageRating: "4.2",
              totalReviews: Math.floor(Math.random() * 800) + 80,
              qualityRating: "4.0",
              valueForMoneyRating: "4.3",
              deliveryExperienceRating: "3.9",
            },
            {
              productId: insertedProduct.id,
              platformId: myntraPlatform.id,
              averageRating: "4.0",
              totalReviews: Math.floor(Math.random() * 600) + 60,
              qualityRating: "3.9",
              valueForMoneyRating: "4.0",
              deliveryExperienceRating: "4.1",
            },
          ];
          
          await db.insert(schema.platformReviews).values(platformReviews);
          console.log(`Platform reviews for ${product.name} created`);
          
          // Add product quality metrics
          const qualityData = {
            productId: insertedProduct.id,
            materialQuality: "4.2",
            buildQuality: "4.1",
            durabilityScore: "4.0",
            overallQualityScore: "4.1",
          };
          
          await db.insert(schema.productQuality).values([qualityData]);
          console.log(`Quality metrics for ${product.name} created`);
        } else {
          console.log(`Product ${product.name} already exists`);
        }
      }
    } else {
      console.error("Missing required references for seeding products");
    }

    console.log("Seed completed successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
