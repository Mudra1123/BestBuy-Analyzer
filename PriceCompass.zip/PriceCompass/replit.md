# BestBuy Analyzer - Price Comparison Platform

## Overview

BestBuy Analyzer is a full-stack price comparison web application that aggregates product prices from multiple e-commerce platforms including Amazon, Flipkart, and Myntra. The application provides real-time price tracking, search functionality, and an AI-powered shopping assistant named Woody to help users find the best deals across platforms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Shadcn/ui component library with Radix UI primitives and Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management and data fetching
- **Real-time Updates**: WebSocket integration for live price updates and notifications

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with WebSocket support for real-time features
- **Service Layer**: Modular service architecture with separate services for products, prices, and AI assistant
- **Middleware**: Custom logging middleware for API request monitoring

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon serverless PostgreSQL for scalable cloud hosting
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Connection Pooling**: Connection pooling via @neondatabase/serverless

### Authentication and Authorization
- **Session Management**: Express sessions with connect-pg-simple for PostgreSQL session storage
- **User Authentication**: Basic username/password authentication system
- **Security**: Credential-based authentication with secure session handling

### External Dependencies

#### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with WebSocket support
- **Drizzle ORM**: Type-safe database toolkit with PostgreSQL dialect support

#### AI and External APIs
- **Perplexity AI**: Powers the Woody shopping assistant for product recommendations and shopping advice
- **WebSocket Server**: Real-time communication for live price updates and notifications

#### UI and Development Tools
- **Shadcn/ui**: Component library providing accessible, customizable UI components
- **Radix UI**: Headless UI primitives for complex components like dialogs, dropdowns, and accordions
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Lucide React**: Icon library for consistent iconography
- **React Hook Form**: Form handling with validation support
- **Date-fns**: Date manipulation and formatting utilities

#### Build and Development
- **Vite**: Fast build tool with HMR support and plugin ecosystem
- **ESBuild**: Fast bundling for production builds
- **TypeScript**: Type safety across the entire stack
- **PostCSS**: CSS processing with Tailwind CSS integration

#### E-commerce Integration
The application is designed to integrate with multiple e-commerce platforms through API connections, currently supporting price comparison across Amazon, Flipkart, Myntra, and other major platforms. Real-time price updates are delivered via WebSocket connections to provide users with live pricing information.