import { log } from "../vite";

interface PerplexityMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface PerplexityResponse {
  id: string;
  model: string;
  object: string;
  created: number;
  choices: {
    index: number;
    finish_reason: string;
    message: {
      role: string;
      content: string;
    };
    delta?: {
      role: string;
      content: string;
    };
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
  citations?: string[];
}

export const assistantService = {
  /**
   * Ask a question to Woody, the AI shopping assistant
   */
  async askWoody(question: string): Promise<string> {
    try {
      if (!process.env.PERPLEXITY_API_KEY) {
        log("Missing Perplexity API key", "assistant-service");
        return "I'm sorry, I can't help with that right now. My connection to the knowledge base is currently unavailable.";
      }

      // Define the system message for Woody
      const systemMessage: PerplexityMessage = {
        role: "system",
        content: 
          "You are Woody, a helpful shopping assistant for a price comparison website. " +
          "Your main goal is to help users find the best deals, understand product features, and make informed " +
          "purchase decisions. You are knowledgeable about electronics (like phones, laptops, watches), " +
          "clothing, and other consumer products. Always be concise, friendly, and focus on providing " +
          "practical shopping advice. If you don't know something specific about current inventory, " +
          "provide general advice about the product category instead."
      };

      // Add the user's question
      const userMessage: PerplexityMessage = {
        role: "user",
        content: question
      };

      const messages = [systemMessage, userMessage];

      // Make the API request to Perplexity
      const response = await fetch("https://api.perplexity.ai/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.PERPLEXITY_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "llama-3.1-sonar-small-128k-online",
          messages,
          temperature: 0.2,
          max_tokens: 300,
          top_p: 0.9,
          stream: false,
          presence_penalty: 0,
          frequency_penalty: 1
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        log(`Perplexity API error: ${errorText}`, "assistant-service");
        return "I'm having trouble connecting to my knowledge base. Could you try asking me again in a different way?";
      }

      const data = await response.json() as PerplexityResponse;
      const aiResponse = data.choices[0]?.message?.content || "I'm not sure how to answer that.";
      
      // Log token usage
      log(`Perplexity API tokens used: ${data.usage.total_tokens}`, "assistant-service");
      
      return aiResponse;
    } catch (error) {
      log(`Error in AI assistant: ${error}`, "assistant-service");
      return "I encountered an error while processing your question. Please try again later.";
    }
  }
};