import { storage } from "../storage";
import { broadcastPriceUpdate, broadcastPriceRefreshComplete } from "../websocket";
import { log } from "../vite";

// Simulate price variation for demo purposes
const getRandomPriceChange = (currentPrice: number) => {
  // Generate a random factor between -0.05 and 0.05 (±5%)
  const changeFactor = (Math.random() * 0.1) - 0.05;
  
  // Apply the change and round to 2 decimal places
  const newPrice = Math.round(currentPrice * (1 + changeFactor) * 100) / 100;
  
  // Ensure price doesn't go negative
  return Math.max(newPrice, 0.01);
};

export const priceService = {
  /**
   * Refresh prices for a specific product across all platforms
   */
  async refreshProductPrices(productId: number) {
    try {
      // Get current prices for the product
      const prices = await storage.getProductPrices(productId);
      const updatedPrices = [];
      
      // In a real application, here we would fetch the latest prices from external APIs
      // For demonstration, we'll simulate price changes instead
      for (const price of prices) {
        // Get current price as a number
        const currentAmount = typeof price.amount === 'number' 
          ? price.amount 
          : parseFloat(price.amount.toString());
          
        // Calculate a new price with small random variation
        const newAmount = getRandomPriceChange(currentAmount);
        
        // Only update if price has actually changed
        if (newAmount !== currentAmount) {
          // Update the price in the database
          const updatedPrice = await storage.updatePrice(price.id, newAmount);
          updatedPrices.push(updatedPrice);
          
          // Broadcast the price update to all connected clients
          broadcastPriceUpdate(
            price.productId, 
            price.platformId, 
            currentAmount, 
            newAmount
          );
          
          log(`Updated price for product ${productId} on platform ${price.platformId}: ${currentAmount} → ${newAmount}`, 'price-service');
        }
      }
      
      return updatedPrices;
    } catch (error) {
      log(`Error refreshing prices for product ${productId}: ${error}`, 'price-service');
      throw error;
    }
  },
  
  /**
   * Refresh prices for all products across all platforms
   */
  async refreshAllPrices() {
    try {
      log('Starting price refresh for all products', 'price-service');
      
      // In a real application, this would be a more sophisticated process that:
      // 1. Fetches new prices from various e-commerce APIs or web scraping
      // 2. Updates the database with new values
      // 3. Notifies any subscribed clients of changes
      
      // For this demo, we'll just call the storage method that updates timestamps
      // and simulate some real refreshes for a few products
      await storage.refreshPrices();
      
      // Get a sample of products to simulate updates for
      const products = await storage.getProducts({ limit: 10 });
      const updatedProductIds = [];
      
      // Refresh prices for each product
      for (const product of products) {
        const updatedPrices = await this.refreshProductPrices(product.id);
        if (updatedPrices.length > 0) {
          updatedProductIds.push(product.id);
        }
      }
      
      // Broadcast completion message with list of updated products
      broadcastPriceRefreshComplete(updatedProductIds);
      
      log(`Completed price refresh. Updated ${updatedProductIds.length} products`, 'price-service');
      return true;
    } catch (error) {
      log(`Error in refreshAllPrices: ${error}`, 'price-service');
      throw error;
    }
  },
  
  /**
   * Check if any price updates are available for a product
   */
  async checkForPriceUpdates(productId: number) {
    try {
      // In a real application, this would check external sources to see if prices have changed
      // For the demo, we'll just simulate a check
      log(`Checking for price updates for product ${productId}`, 'price-service');
      return Math.random() > 0.5; // Randomly determine if updates are available
    } catch (error) {
      log(`Error checking for price updates: ${error}`, 'price-service');
      return false;
    }
  },
  
  /**
   * Get the time since the last price update for a product
   */
  async getTimeSinceLastUpdate(productId: number) {
    try {
      const prices = await storage.getProductPrices(productId);
      if (!prices || prices.length === 0) {
        return null;
      }
      
      // Find the most recent lastUpdated timestamp
      const mostRecent = prices.reduce((latest, current) => {
        const currentTime = new Date(current.lastUpdated).getTime();
        const latestTime = new Date(latest.lastUpdated).getTime();
        return currentTime > latestTime ? current : latest;
      });
      
      return mostRecent.lastUpdated;
    } catch (error) {
      log(`Error getting last update time: ${error}`, 'price-service');
      return null;
    }
  },
  
  /**
   * Schedule automatic price refresh at regular intervals
   * This would be called during app initialization in a real application
   */
  scheduleAutomaticRefresh(intervalMinutes = 60) {
    const interval = intervalMinutes * 60 * 1000;
    
    log(`Scheduling automatic price refresh every ${intervalMinutes} minutes`, 'price-service');
    
    // Set up the interval
    const timerId = setInterval(async () => {
      try {
        log('Running scheduled price refresh', 'price-service');
        await this.refreshAllPrices();
      } catch (error) {
        log(`Error in scheduled price refresh: ${error}`, 'price-service');
      }
    }, interval);
    
    // Return the timer ID so it can be cleared if needed
    return timerId;
  }
};
