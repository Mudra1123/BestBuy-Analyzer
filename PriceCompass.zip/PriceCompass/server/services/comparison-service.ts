import { ProductWithComprehensiveData } from "@shared/schema";

export interface ComparisonMetrics {
  price: number;
  rating: number;
  delivery: number;
  quality: number;
  returnPolicy: number;
  valueForMoney: number;
  overallScore: number;
}

export interface PlatformComparison {
  platformId: number;
  platformName: string;
  platformSlug: string;
  colorCode: string;
  price: number;
  rating: number;
  reviewCount: number;
  deliveryTimeMin: number;
  deliveryTimeMax: number;
  shippingCost: number;
  returnPolicyDays: number;
  returnPolicyRating: number;
  customerServiceRating: number;
  qualityRating: number;
  valueForMoneyRating: number;
  deliveryExperienceRating: number;
  metrics: ComparisonMetrics;
  isAvailable: boolean;
  url: string;
}

export interface ProductComparison {
  product: ProductWithComprehensiveData;
  platforms: PlatformComparison[];
  bestPrice: PlatformComparison;
  bestRating: PlatformComparison;
  fastestDelivery: PlatformComparison;
  bestQuality: PlatformComparison;
  bestValue: PlatformComparison;
  recommended: PlatformComparison;
}

export const comparisonService = {
  calculateMetrics(platform: PlatformComparison): ComparisonMetrics {
    // Normalize all metrics to 0-1 scale for comparison
    const priceScore = Math.max(0, Math.min(1, (200000 - platform.price) / 200000)); // Higher score for lower price
    const ratingScore = platform.rating / 5; // 0-1 scale
    const deliveryScore = Math.max(0, Math.min(1, (10 - platform.deliveryTimeMin) / 10)); // Higher score for faster delivery
    const qualityScore = platform.qualityRating / 5; // 0-1 scale
    const returnPolicyScore = Math.min(1, platform.returnPolicyDays / 30); // 0-1 scale, 30 days = perfect
    const valueScore = platform.valueForMoneyRating / 5; // 0-1 scale

    // Weighted overall score (you can adjust these weights based on user preferences)
    const overallScore = (
      priceScore * 0.25 +
      ratingScore * 0.20 +
      deliveryScore * 0.15 +
      qualityScore * 0.20 +
      returnPolicyScore * 0.10 +
      valueScore * 0.10
    );

    return {
      price: priceScore,
      rating: ratingScore,
      delivery: deliveryScore,
      quality: qualityScore,
      returnPolicy: returnPolicyScore,
      valueForMoney: valueScore,
      overallScore
    };
  },

  compareProduct(product: ProductWithComprehensiveData): ProductComparison {
    // Build platform comparisons
    const platforms: PlatformComparison[] = product.prices.map(price => {
      const platformReview = product.platformReviews?.find(r => r.platformId === price.platformId);
      
      const platformComparison: PlatformComparison = {
        platformId: price.platformId,
        platformName: price.platform.name,
        platformSlug: price.platform.slug,
        colorCode: price.platform.colorCode || "#000000",
        price: typeof price.amount === 'number' ? price.amount : parseFloat(price.amount.toString()),
        rating: platformReview ? parseFloat(platformReview.averageRating.toString()) : 0,
        reviewCount: platformReview?.totalReviews || 0,
        deliveryTimeMin: price.platform.deliveryTimeMin || 7,
        deliveryTimeMax: price.platform.deliveryTimeMax || 14,
        shippingCost: price.platform.shippingCost ? parseFloat(price.platform.shippingCost.toString()) : 0,
        returnPolicyDays: price.platform.returnPolicyDays || 0,
        returnPolicyRating: price.platform.returnPolicyRating ? parseFloat(price.platform.returnPolicyRating.toString()) : 0,
        customerServiceRating: price.platform.customerServiceRating ? parseFloat(price.platform.customerServiceRating.toString()) : 0,
        qualityRating: platformReview?.qualityRating ? parseFloat(platformReview.qualityRating.toString()) : 0,
        valueForMoneyRating: platformReview?.valueForMoneyRating ? parseFloat(platformReview.valueForMoneyRating.toString()) : 0,
        deliveryExperienceRating: platformReview?.deliveryExperienceRating ? parseFloat(platformReview.deliveryExperienceRating.toString()) : 0,
        isAvailable: price.isAvailable || false,
        url: price.url || "#",
        metrics: { price: 0, rating: 0, delivery: 0, quality: 0, returnPolicy: 0, valueForMoney: 0, overallScore: 0 }
      };

      // Calculate metrics
      platformComparison.metrics = this.calculateMetrics(platformComparison);
      
      return platformComparison;
    }).filter(p => p.isAvailable);

    // Find best options
    const bestPrice = platforms.reduce((best, current) => 
      current.price < best.price ? current : best
    );
    
    const bestRating = platforms.reduce((best, current) => 
      current.rating > best.rating ? current : best
    );
    
    const fastestDelivery = platforms.reduce((best, current) => 
      current.deliveryTimeMin < best.deliveryTimeMin ? current : best
    );
    
    const bestQuality = platforms.reduce((best, current) => 
      current.qualityRating > best.qualityRating ? current : best
    );
    
    const bestValue = platforms.reduce((best, current) => 
      current.valueForMoneyRating > best.valueForMoneyRating ? current : best
    );
    
    const recommended = platforms.reduce((best, current) => 
      current.metrics.overallScore > best.metrics.overallScore ? current : best
    );

    return {
      product,
      platforms,
      bestPrice,
      bestRating,
      fastestDelivery,
      bestQuality,
      bestValue,
      recommended
    };
  },

  filterByComparison(products: ProductWithComprehensiveData[], filters: {
    minRating?: number;
    maxDeliveryTime?: number;
    minReturnPolicyDays?: number;
    qualityThreshold?: number;
  }): ProductWithComprehensiveData[] {
    return products.filter(product => {
      const comparison = this.compareProduct(product);
      
      // Check if any platform meets the criteria
      return comparison.platforms.some(platform => {
        if (filters.minRating && platform.rating < filters.minRating) return false;
        if (filters.maxDeliveryTime && platform.deliveryTimeMin > filters.maxDeliveryTime) return false;
        if (filters.minReturnPolicyDays && platform.returnPolicyDays < filters.minReturnPolicyDays) return false;
        if (filters.qualityThreshold && platform.qualityRating < filters.qualityThreshold) return false;
        return true;
      });
    });
  },

  getBestDeals(products: ProductWithComprehensiveData[], limit: number = 10): ProductComparison[] {
    return products
      .map(product => this.compareProduct(product))
      .sort((a, b) => b.recommended.metrics.overallScore - a.recommended.metrics.overallScore)
      .slice(0, limit);
  },

  getRecommendationReason(comparison: ProductComparison): string {
    const recommended = comparison.recommended;
    const reasons: string[] = [];

    if (recommended === comparison.bestPrice) {
      reasons.push("lowest price");
    }
    if (recommended === comparison.bestRating) {
      reasons.push("highest ratings");
    }
    if (recommended === comparison.fastestDelivery) {
      reasons.push("fastest delivery");
    }
    if (recommended === comparison.bestQuality) {
      reasons.push("best quality");
    }
    if (recommended === comparison.bestValue) {
      reasons.push("best value for money");
    }

    if (reasons.length === 0) {
      return "best overall combination of price, quality, delivery, and customer ratings";
    }

    return reasons.join(", ");
  }
};