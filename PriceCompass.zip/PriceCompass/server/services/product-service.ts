import { storage } from "../storage";

export const productService = {
  /**
   * Get filtered products with prices
   */
  async getFilteredProducts(filters: any) {
    return storage.getProducts(filters);
  },
  
  /**
   * Get a product by its slug
   */
  async getProductBySlug(slug: string) {
    return storage.getProductBySlug(slug);
  },
  
  /**
   * Get a product by its ID
   */
  async getProductById(id: number) {
    return storage.getProductById(id);
  },
  
  /**
   * Get all prices for a specific product
   */
  async getProductPrices(productId: number) {
    return storage.getProductPrices(productId);
  },
  
  /**
   * Find the best price (lowest) for a product across all platforms
   */
  async findBestPrice(productId: number) {
    const prices = await storage.getProductPrices(productId);
    
    if (!prices || prices.length === 0) {
      return null;
    }
    
    return prices.reduce((best, current) => {
      const currentAmount = typeof current.amount === 'number' 
        ? current.amount 
        : parseFloat(current.amount.toString());
        
      const bestAmount = typeof best.amount === 'number'
        ? best.amount
        : parseFloat(best.amount.toString());
        
      return currentAmount < bestAmount ? current : best;
    });
  },
  
  /**
   * Check if a product has a price at or below the specified amount
   */
  async hasPriceBelow(productId: number, amount: number) {
    const prices = await storage.getProductPrices(productId);
    
    if (!prices || prices.length === 0) {
      return false;
    }
    
    return prices.some(price => {
      const priceAmount = typeof price.amount === 'number'
        ? price.amount
        : parseFloat(price.amount.toString());
        
      return priceAmount <= amount;
    });
  },
};
