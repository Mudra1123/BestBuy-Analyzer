import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { productService } from "./services/product-service";
import { priceService } from "./services/price-service";
import { assistantService } from "./services/assistant-service";
import { comparisonService } from "./services/comparison-service";
import { setupWebsocketHandlers } from "./websocket";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time price updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  setupWebsocketHandlers(wss);

  // API Routes - prefix all routes with /api
  
  // Categories
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error('Error fetching categories:', error);
      res.status(500).json({ message: 'Failed to fetch categories' });
    }
  });

  app.get('/api/categories/:slug', async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: 'Category not found' });
      }
      res.json(category);
    } catch (error) {
      console.error('Error fetching category:', error);
      res.status(500).json({ message: 'Failed to fetch category' });
    }
  });

  // Brands
  app.get('/api/brands', async (req, res) => {
    try {
      const brands = await storage.getBrands();
      res.json(brands);
    } catch (error) {
      console.error('Error fetching brands:', error);
      res.status(500).json({ message: 'Failed to fetch brands' });
    }
  });

  // Genders
  app.get('/api/genders', async (req, res) => {
    try {
      const genders = await storage.getGenders();
      res.json(genders);
    } catch (error) {
      console.error('Error fetching genders:', error);
      res.status(500).json({ message: 'Failed to fetch genders' });
    }
  });

  // Sizes
  app.get('/api/sizes', async (req, res) => {
    try {
      const sizes = await storage.getSizes();
      res.json(sizes);
    } catch (error) {
      console.error('Error fetching sizes:', error);
      res.status(500).json({ message: 'Failed to fetch sizes' });
    }
  });

  // Platforms
  app.get('/api/platforms', async (req, res) => {
    try {
      const platforms = await storage.getPlatforms();
      res.json(platforms);
    } catch (error) {
      console.error('Error fetching platforms:', error);
      res.status(500).json({ message: 'Failed to fetch platforms' });
    }
  });

  // Products
  app.get('/api/products', async (req, res) => {
    try {
      const {
        q,
        category,
        brand,
        gender,
        size,
        minPrice,
        maxPrice,
        sortBy,
        limit,
        page = 1,
      } = req.query;

      // Build filters object
      const filters: any = {};

      if (q) filters.searchQuery = q as string;
      
      if (category) {
        const categories = Array.isArray(category) 
          ? category as string[] 
          : [category as string];
        filters.categories = categories;
      }
      
      if (brand) {
        const brands = Array.isArray(brand) 
          ? brand as string[] 
          : [brand as string];
        filters.brands = brands;
      }
      
      if (gender) {
        const genders = Array.isArray(gender) 
          ? gender as string[] 
          : [gender as string];
        filters.genders = genders;
      }
      
      if (size) {
        const sizes = Array.isArray(size) 
          ? size as string[] 
          : [size as string];
        filters.sizes = sizes;
      }
      
      if (minPrice !== undefined && maxPrice !== undefined) {
        filters.priceRange = [
          parseInt(minPrice as string, 10), 
          parseInt(maxPrice as string, 10)
        ];
      }
      
      if (sortBy) filters.sortBy = sortBy as string;
      
      if (limit) filters.limit = parseInt(limit as string, 10);
      
      filters.offset = (parseInt(page as string, 10) - 1) * (filters.limit || 20);

      const products = await productService.getFilteredProducts(filters);
      res.json(products);
    } catch (error) {
      console.error('Error fetching products:', error);
      res.status(500).json({ message: 'Failed to fetch products' });
    }
  });

  app.get('/api/products/:slug', async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      res.json(product);
    } catch (error) {
      console.error('Error fetching product:', error);
      res.status(500).json({ message: 'Failed to fetch product' });
    }
  });

  // Prices
  app.get('/api/products/:id/prices', async (req, res) => {
    try {
      const productId = parseInt(req.params.id, 10);
      const prices = await storage.getProductPrices(productId);
      res.json(prices);
    } catch (error) {
      console.error('Error fetching product prices:', error);
      res.status(500).json({ message: 'Failed to fetch product prices' });
    }
  });

  app.post('/api/prices/refresh', async (req, res) => {
    try {
      await priceService.refreshAllPrices();
      res.json({ success: true, message: 'Prices refreshed successfully' });
    } catch (error) {
      console.error('Error refreshing prices:', error);
      res.status(500).json({ message: 'Failed to refresh prices' });
    }
  });
  
  // Refresh price for specific product
  app.post('/api/products/:id/refresh-price', async (req, res) => {
    try {
      const productId = parseInt(req.params.id, 10);
      const product = await storage.getProductById(productId);
      
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      const updatedPrices = await priceService.refreshProductPrices(productId);
      res.json({ 
        success: true, 
        message: 'Product prices refreshed successfully',
        prices: updatedPrices
      });
    } catch (error) {
      console.error(`Error refreshing product prices: ${error}`);
      res.status(500).json({ message: 'Failed to refresh product prices' });
    }
  });
  
  // AI Assistant - Woody
  app.post('/api/assistant/woody', async (req, res) => {
    try {
      const { question } = req.body;
      
      if (!question || typeof question !== 'string') {
        return res.status(400).json({ 
          message: 'Invalid request. Please provide a question.' 
        });
      }
      
      const answer = await assistantService.askWoody(question);
      res.json({ 
        success: true,
        answer
      });
    } catch (error) {
      console.error(`Error with AI assistant: ${error}`);
      res.status(500).json({ 
        message: 'Sorry, Woody is having trouble answering your question right now.' 
      });
    }
  });

  // Comprehensive Comparison API
  app.get('/api/comparison/product/:slug', async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      const comparison = comparisonService.compareProduct(product);
      const recommendationReason = comparisonService.getRecommendationReason(comparison);
      
      res.json({
        ...comparison,
        recommendationReason
      });
    } catch (error) {
      console.error(`Error comparing product: ${error}`);
      res.status(500).json({ message: 'Failed to generate product comparison' });
    }
  });

  app.get('/api/comparison/best-deals', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const category = req.query.category as string;
      
      const filters: any = {};
      if (category && category !== 'all_categories') {
        filters.categories = [category];
      }
      
      const products = await storage.getProducts(filters);
      const bestDeals = comparisonService.getBestDeals(products, limit);
      
      res.json({
        success: true,
        deals: bestDeals.map(deal => ({
          ...deal,
          recommendationReason: comparisonService.getRecommendationReason(deal)
        }))
      });
    } catch (error) {
      console.error(`Error fetching best deals: ${error}`);
      res.status(500).json({ message: 'Failed to fetch best deals' });
    }
  });

  app.get('/api/comparison/metrics/:productId', async (req, res) => {
    try {
      const productId = parseInt(req.params.productId, 10);
      const product = await storage.getProductById(productId);
      
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      const comparison = comparisonService.compareProduct(product);
      
      res.json({
        success: true,
        platforms: comparison.platforms.map(platform => ({
          platformName: platform.platformName,
          platformSlug: platform.platformSlug,
          colorCode: platform.colorCode,
          metrics: platform.metrics,
          summary: {
            price: platform.price,
            rating: platform.rating,
            deliveryTime: `${platform.deliveryTimeMin}-${platform.deliveryTimeMax} days`,
            returnPolicy: `${platform.returnPolicyDays} days`,
            shippingCost: platform.shippingCost
          }
        }))
      });
    } catch (error) {
      console.error(`Error fetching comparison metrics: ${error}`);
      res.status(500).json({ message: 'Failed to fetch comparison metrics' });
    }
  });

  return httpServer;
}
