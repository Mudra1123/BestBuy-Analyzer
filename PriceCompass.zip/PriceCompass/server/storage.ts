import { db } from "@db";
import * as schema from "@shared/schema";
import { eq, and, or, between, like, desc, asc, inArray } from "drizzle-orm";
import { ProductWithPrices } from "@shared/schema";

export interface ProductFilters {
  searchQuery?: string;
  categories?: string[];
  brands?: string[];
  genders?: string[];
  sizes?: string[];
  priceRange?: [number, number];
  sortBy?: string;
  limit?: number;
  offset?: number;
  // New comprehensive comparison filters
  minRating?: number;
  maxDeliveryTime?: number;
  minReturnPolicyDays?: number;
  qualityThreshold?: number;
}

export const storage = {
  // Categories
  async getCategories() {
    return db.query.categories.findMany({
      orderBy: (categories) => [asc(categories.name)],
    });
  },

  async getCategoryBySlug(slug: string) {
    return db.query.categories.findFirst({
      where: (categories) => eq(categories.slug, slug),
    });
  },

  // Brands
  async getBrands() {
    return db.query.brands.findMany({
      orderBy: (brands) => [asc(brands.name)],
    });
  },

  async getBrandBySlug(slug: string) {
    return db.query.brands.findFirst({
      where: (brands) => eq(brands.slug, slug),
    });
  },

  // Genders
  async getGenders() {
    return db.query.genders.findMany();
  },

  async getGenderBySlug(slug: string) {
    return db.query.genders.findFirst({
      where: (genders) => eq(genders.slug, slug),
    });
  },

  // Sizes
  async getSizes() {
    return db.query.sizes.findMany();
  },

  // Platforms
  async getPlatforms() {
    return db.query.platforms.findMany();
  },

  async getPlatformBySlug(slug: string) {
    return db.query.platforms.findFirst({
      where: (platforms) => eq(platforms.slug, slug),
    });
  },

  // Products
  async getProducts(filters: ProductFilters = {}) {
    const {
      searchQuery,
      categories,
      brands,
      genders,
      sizes,
      priceRange,
      sortBy = "popular",
      limit = 20,
      offset = 0,
    } = filters;

    let query = db.query.products.findMany({
      limit,
      offset,
      with: {
        prices: {
          with: {
            platform: true,
          },
        },
        category: true,
        brand: true,
        gender: true,
      },
    });

    // Apply filters if provided
    const whereConditions = [];

    // Search query
    if (searchQuery && searchQuery.trim() !== "") {
      whereConditions.push(like(schema.products.name, `%${searchQuery}%`));
    }

    // Categories
    if (categories && categories.length > 0) {
      const categoryIds = await db.select({ id: schema.categories.id })
        .from(schema.categories)
        .where(inArray(schema.categories.slug, categories));
      
      if (categoryIds.length > 0) {
        whereConditions.push(inArray(schema.products.categoryId, categoryIds.map(c => c.id)));
      }
    }

    // Brands
    if (brands && brands.length > 0) {
      const brandIds = await db.select({ id: schema.brands.id })
        .from(schema.brands)
        .where(inArray(schema.brands.slug, brands));
      
      if (brandIds.length > 0) {
        whereConditions.push(inArray(schema.products.brandId, brandIds.map(b => b.id)));
      }
    }

    // Genders
    if (genders && genders.length > 0) {
      const genderIds = await db.select({ id: schema.genders.id })
        .from(schema.genders)
        .where(inArray(schema.genders.slug, genders));
      
      if (genderIds.length > 0) {
        whereConditions.push(inArray(schema.products.genderId, genderIds.map(g => g.id)));
      }
    }

    // Sizes
    if (sizes && sizes.length > 0) {
      const sizeIds = await db.select({ id: schema.sizes.id })
        .from(schema.sizes)
        .where(inArray(schema.sizes.name, sizes));
      
      if (sizeIds.length > 0) {
        const productIds = await db.select({ productId: schema.productSizes.productId })
          .from(schema.productSizes)
          .where(inArray(schema.productSizes.sizeId, sizeIds.map(s => s.id)));
        
        if (productIds.length > 0) {
          whereConditions.push(inArray(schema.products.id, productIds.map(p => p.productId)));
        }
      }
    }

    // Price range
    if (priceRange && priceRange.length === 2) {
      const [minPrice, maxPrice] = priceRange;
      
      // Find products with prices in the given range across any platform
      const productIds = await db.select({ productId: schema.prices.productId })
        .from(schema.prices)
        .where(
          and(
            between(schema.prices.amount, minPrice, maxPrice),
            eq(schema.prices.isAvailable, true)
          )
        );
      
      if (productIds.length > 0) {
        whereConditions.push(inArray(schema.products.id, [...new Set(productIds.map(p => p.productId))]));
      }
    }

    // Apply all filters
    if (whereConditions.length > 0) {
      query = db.query.products.findMany({
        where: and(...whereConditions),
        limit,
        offset,
        with: {
          prices: {
            with: {
              platform: true,
            },
          },
          platformReviews: {
            with: {
              platform: true,
            },
          },
          quality: true,
          category: true,
          brand: true,
          gender: true,
        },
      });
    }

    // Get the products
    let products = await query;

    // Sort products
    products = products.sort((a, b) => {
      if (sortBy === "price_asc") {
        const aMinPrice = Math.min(...a.prices.map(p => typeof p.amount === 'number' ? p.amount : parseFloat(p.amount.toString())));
        const bMinPrice = Math.min(...b.prices.map(p => typeof p.amount === 'number' ? p.amount : parseFloat(p.amount.toString())));
        return aMinPrice - bMinPrice;
      } else if (sortBy === "price_desc") {
        const aMinPrice = Math.min(...a.prices.map(p => typeof p.amount === 'number' ? p.amount : parseFloat(p.amount.toString())));
        const bMinPrice = Math.min(...b.prices.map(p => typeof p.amount === 'number' ? p.amount : parseFloat(p.amount.toString())));
        return bMinPrice - aMinPrice;
      } else if (sortBy === "rating") {
        // Sort by average rating across all platforms
        const aAvgRating = a.platformReviews?.length ? 
          a.platformReviews.reduce((sum, r) => sum + parseFloat(r.averageRating.toString()), 0) / a.platformReviews.length : 0;
        const bAvgRating = b.platformReviews?.length ? 
          b.platformReviews.reduce((sum, r) => sum + parseFloat(r.averageRating.toString()), 0) / b.platformReviews.length : 0;
        return bAvgRating - aAvgRating;
      } else if (sortBy === "delivery") {
        // Sort by fastest delivery (minimum delivery time across platforms)
        const aMinDelivery = Math.min(...a.prices.map(p => p.platform.deliveryTimeMin || 99));
        const bMinDelivery = Math.min(...b.prices.map(p => p.platform.deliveryTimeMin || 99));
        return aMinDelivery - bMinDelivery;
      } else if (sortBy === "quality") {
        // Sort by overall quality score
        const aQuality = a.quality?.overallQualityScore ? parseFloat(a.quality.overallQualityScore.toString()) : 0;
        const bQuality = b.quality?.overallQualityScore ? parseFloat(b.quality.overallQualityScore.toString()) : 0;
        return bQuality - aQuality;
      } else if (sortBy === "best_value") {
        // Sort by value for money (weighted combination of price, quality, and ratings)
        const aMinPrice = Math.min(...a.prices.map(p => typeof p.amount === 'number' ? p.amount : parseFloat(p.amount.toString())));
        const bMinPrice = Math.min(...b.prices.map(p => typeof p.amount === 'number' ? p.amount : parseFloat(p.amount.toString())));
        const aAvgRating = a.platformReviews?.length ? 
          a.platformReviews.reduce((sum, r) => sum + parseFloat(r.averageRating.toString()), 0) / a.platformReviews.length : 0;
        const bAvgRating = b.platformReviews?.length ? 
          b.platformReviews.reduce((sum, r) => sum + parseFloat(r.averageRating.toString()), 0) / b.platformReviews.length : 0;
        const aQuality = a.quality?.overallQualityScore ? parseFloat(a.quality.overallQualityScore.toString()) : 0;
        const bQuality = b.quality?.overallQualityScore ? parseFloat(b.quality.overallQualityScore.toString()) : 0;
        
        // Calculate value score (higher is better: rating * quality / normalized_price)
        const aValue = (aAvgRating * aQuality) / (aMinPrice / 1000);
        const bValue = (bAvgRating * bQuality) / (bMinPrice / 1000);
        return bValue - aValue;
      } else if (sortBy === "popular") {
        // Default: sort by popularity (review count)
        return (b.reviewCount || 0) - (a.reviewCount || 0);
      }
      return 0;
    });

    return products;
  },

  async getProductBySlug(slug: string): Promise<ProductWithPrices | null> {
    return db.query.products.findFirst({
      where: (products) => eq(products.slug, slug),
      with: {
        prices: {
          with: {
            platform: true,
          },
        },
        platformReviews: {
          with: {
            platform: true,
          },
        },
        quality: true,
        category: true,
        brand: true,
        gender: true,
      },
    });
  },

  async getProductById(id: number): Promise<ProductWithPrices | null> {
    return db.query.products.findFirst({
      where: (products) => eq(products.id, id),
      with: {
        prices: {
          with: {
            platform: true,
          },
        },
        platformReviews: {
          with: {
            platform: true,
          },
        },
        quality: true,
        category: true,
        brand: true,
        gender: true,
      },
    });
  },

  // Prices
  async getProductPrices(productId: number) {
    return db.query.prices.findMany({
      where: (prices) => eq(prices.productId, productId),
      with: {
        platform: true,
      },
    });
  },

  async updatePrice(id: number, amount: number) {
    const [updatedPrice] = await db
      .update(schema.prices)
      .set({ amount, lastUpdated: new Date() })
      .where(eq(schema.prices.id, id))
      .returning();
    return updatedPrice;
  },

  async refreshPrices() {
    // In a real application, this would call external APIs to fetch updated prices
    // For this demo, we'll just update the lastUpdated timestamp
    const prices = await db.query.prices.findMany();
    
    for (const price of prices) {
      await db
        .update(schema.prices)
        .set({ lastUpdated: new Date() })
        .where(eq(schema.prices.id, price.id));
    }
    
    return true;
  },
};
