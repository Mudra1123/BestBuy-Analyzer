import { WebSocketServer, WebSocket } from 'ws';
import { log } from './vite';

// Store active connections
const clients = new Set<WebSocket>();

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

export function setupWebsocketHandlers(wss: WebSocketServer) {
  wss.on('connection', (ws) => {
    log('WebSocket client connected', 'websocket');
    
    // Add to our connected clients set
    clients.add(ws);
    
    // Handle messages from clients
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString()) as WebSocketMessage;
        
        // Handle different message types
        switch (data.type) {
          case 'REFRESH_PRICES':
            log('Received price refresh request', 'websocket');
            // This will be handled by the server endpoint, but we can notify clients
            broadcastMessage({
              type: 'PRICE_REFRESH_STARTED',
              timestamp: new Date().toISOString()
            });
            break;
            
          default:
            log(`Received unknown message type: ${data.type}`, 'websocket');
        }
      } catch (error) {
        log(`Error processing WebSocket message: ${error}`, 'websocket');
      }
    });
    
    // Handle disconnection
    ws.on('close', () => {
      clients.delete(ws);
      log('WebSocket client disconnected', 'websocket');
    });
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({
      type: 'CONNECTED',
      message: 'Connected to BestBuy Analyzer real-time price updates',
      timestamp: new Date().toISOString()
    }));
  });
  
  // Log errors
  wss.on('error', (error) => {
    log(`WebSocket server error: ${error}`, 'websocket');
  });
  
  log('WebSocket server initialized', 'websocket');
}

// Broadcast a message to all connected clients
export function broadcastMessage(message: any) {
  const messageString = JSON.stringify(message);
  
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(messageString);
    }
  });
}

// Send a price update to all clients
export function broadcastPriceUpdate(productId: number, platformId: number, oldPrice: number, newPrice: number) {
  broadcastMessage({
    type: 'PRICE_UPDATE',
    payload: {
      productId,
      platformId,
      oldPrice,
      newPrice,
      timestamp: new Date().toISOString()
    }
  });
}

// Notify clients when a price refresh is complete
export function broadcastPriceRefreshComplete(updatedProductIds: number[]) {
  broadcastMessage({
    type: 'PRICE_REFRESH_COMPLETE',
    payload: {
      timestamp: new Date().toISOString(),
      updatedProductIds
    }
  });
}
