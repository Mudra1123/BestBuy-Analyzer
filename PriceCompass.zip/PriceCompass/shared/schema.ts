import { pgTable, text, serial, integer, boolean, timestamp, decimal, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table (keeping as is)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  icon: text("icon"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCategorySchema = createInsertSchema(categories);
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Brands table
export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBrandSchema = createInsertSchema(brands);
export type InsertBrand = z.infer<typeof insertBrandSchema>;
export type Brand = typeof brands.$inferSelect;

// Genders enum for products
export const genders = pgTable("genders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
});

export const insertGenderSchema = createInsertSchema(genders);
export type InsertGender = z.infer<typeof insertGenderSchema>;
export type Gender = typeof genders.$inferSelect;

// Sizes table
export const sizes = pgTable("sizes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSizeSchema = createInsertSchema(sizes);
export type InsertSize = z.infer<typeof insertSizeSchema>;
export type Size = typeof sizes.$inferSelect;

// Products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  rating: decimal("rating", { precision: 3, scale: 1 }),
  reviewCount: integer("review_count").default(0),
  categoryId: integer("category_id").references(() => categories.id).notNull(),
  brandId: integer("brand_id").references(() => brands.id).notNull(),
  genderId: integer("gender_id").references(() => genders.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertProductSchema = createInsertSchema(products);
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// Product-Size relationship
export const productSizes = pgTable("product_sizes", {
  productId: integer("product_id").references(() => products.id).notNull(),
  sizeId: integer("size_id").references(() => sizes.id).notNull(),
}, (t) => ({
  pk: primaryKey({ columns: [t.productId, t.sizeId] }),
}));

export const insertProductSizeSchema = createInsertSchema(productSizes);
export type InsertProductSize = z.infer<typeof insertProductSizeSchema>;
export type ProductSize = typeof productSizes.$inferSelect;

// E-commerce platforms
export const platforms = pgTable("platforms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  logoUrl: text("logo_url"),
  colorCode: text("color_code"),
  deliveryTimeMin: integer("delivery_time_min"), // min delivery days
  deliveryTimeMax: integer("delivery_time_max"), // max delivery days
  shippingCost: decimal("shipping_cost", { precision: 8, scale: 2 }), // shipping cost
  returnPolicyDays: integer("return_policy_days"), // days for returns
  returnPolicyRating: decimal("return_policy_rating", { precision: 3, scale: 1 }), // 1-5 rating
  customerServiceRating: decimal("customer_service_rating", { precision: 3, scale: 1 }), // 1-5 rating
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPlatformSchema = createInsertSchema(platforms);
export type InsertPlatform = z.infer<typeof insertPlatformSchema>;
export type Platform = typeof platforms.$inferSelect;

// Prices for products across platforms
export const prices = pgTable("prices", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  platformId: integer("platform_id").references(() => platforms.id).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  url: text("url"),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
  isAvailable: boolean("is_available").default(true),
});

export const insertPriceSchema = createInsertSchema(prices);
export type InsertPrice = z.infer<typeof insertPriceSchema>;
export type Price = typeof prices.$inferSelect;

// Platform Reviews for products - aggregated review data per platform
export const platformReviews = pgTable("platform_reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  platformId: integer("platform_id").references(() => platforms.id).notNull(),
  averageRating: decimal("average_rating", { precision: 3, scale: 1 }).notNull(), // 1-5 rating
  totalReviews: integer("total_reviews").default(0).notNull(),
  qualityRating: decimal("quality_rating", { precision: 3, scale: 1 }), // 1-5 quality score
  valueForMoneyRating: decimal("value_for_money_rating", { precision: 3, scale: 1 }), // 1-5 value score
  deliveryExperienceRating: decimal("delivery_experience_rating", { precision: 3, scale: 1 }), // 1-5 delivery score
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertPlatformReviewSchema = createInsertSchema(platformReviews);
export type InsertPlatformReview = z.infer<typeof insertPlatformReviewSchema>;
export type PlatformReview = typeof platformReviews.$inferSelect;

// Product Quality Metrics - overall quality assessment
export const productQuality = pgTable("product_quality", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  materialQuality: decimal("material_quality", { precision: 3, scale: 1 }), // 1-5 rating
  buildQuality: decimal("build_quality", { precision: 3, scale: 1 }), // 1-5 rating
  durabilityScore: decimal("durability_score", { precision: 3, scale: 1 }), // 1-5 rating
  overallQualityScore: decimal("overall_quality_score", { precision: 3, scale: 1 }), // 1-5 rating
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertProductQualitySchema = createInsertSchema(productQuality);
export type InsertProductQuality = z.infer<typeof insertProductQualitySchema>;
export type ProductQuality = typeof productQuality.$inferSelect;

// Define relations
export const categoriesRelations = relations(categories, ({ many }) => ({
  products: many(products),
}));

export const brandsRelations = relations(brands, ({ many }) => ({
  products: many(products),
}));

export const gendersRelations = relations(genders, ({ many }) => ({
  products: many(products),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  category: one(categories, { fields: [products.categoryId], references: [categories.id] }),
  brand: one(brands, { fields: [products.brandId], references: [brands.id] }),
  gender: one(genders, { fields: [products.genderId], references: [genders.id] }),
  sizes: many(productSizes),
  prices: many(prices),
  platformReviews: many(platformReviews),
  quality: one(productQuality, { fields: [products.id], references: [productQuality.productId] }),
}));

export const sizesRelations = relations(sizes, ({ many }) => ({
  products: many(productSizes),
}));

export const productSizesRelations = relations(productSizes, ({ one }) => ({
  product: one(products, { fields: [productSizes.productId], references: [products.id] }),
  size: one(sizes, { fields: [productSizes.sizeId], references: [sizes.id] }),
}));

export const platformsRelations = relations(platforms, ({ many }) => ({
  prices: many(prices),
  reviews: many(platformReviews),
}));

export const pricesRelations = relations(prices, ({ one }) => ({
  product: one(products, { fields: [prices.productId], references: [products.id] }),
  platform: one(platforms, { fields: [prices.platformId], references: [platforms.id] }),
}));

export const platformReviewsRelations = relations(platformReviews, ({ one }) => ({
  product: one(products, { fields: [platformReviews.productId], references: [products.id] }),
  platform: one(platforms, { fields: [platformReviews.platformId], references: [platforms.id] }),
}));

export const productQualityRelations = relations(productQuality, ({ one }) => ({
  product: one(products, { fields: [productQuality.productId], references: [products.id] }),
}));

// Combined product with comprehensive data schema
export const productWithComprehensiveDataSchema = createSelectSchema(products).extend({
  prices: z.array(
    createSelectSchema(prices).extend({
      platform: createSelectSchema(platforms),
    })
  ),
  platformReviews: z.array(
    createSelectSchema(platformReviews).extend({
      platform: createSelectSchema(platforms),
    })
  ),
  quality: createSelectSchema(productQuality).nullable(),
  category: createSelectSchema(categories),
  brand: createSelectSchema(brands),
  gender: createSelectSchema(genders).nullable(),
});

export type ProductWithComprehensiveData = z.infer<typeof productWithComprehensiveDataSchema>;

// Backwards compatibility
export const productWithPricesSchema = productWithComprehensiveDataSchema;
export type ProductWithPrices = ProductWithComprehensiveData;
