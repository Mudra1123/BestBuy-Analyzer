import { useState, useEffect, useRef, useCallback } from 'react';

interface UseWebSocketOptions {
  reconnectInterval?: number;
  reconnectAttempts?: number;
  onOpen?: (event: WebSocketEventMap['open']) => void;
  onMessage?: (event: WebSocketEventMap['message']) => void;
  onClose?: (event: WebSocketEventMap['close']) => void;
  onError?: (event: WebSocketEventMap['error']) => void;
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const {
    reconnectInterval = 3000,
    reconnectAttempts = 5,
    onOpen,
    onMessage,
    onClose,
    onError,
  } = options;

  const [lastMessage, setLastMessage] = useState<MessageEvent | null>(null);
  const [readyState, setReadyState] = useState<number>(WebSocket.CONNECTING);
  const [reconnectCount, setReconnectCount] = useState(0);
  
  const socketRef = useRef<WebSocket | null>(null);
  
  // Create WebSocket connection
  const connect = useCallback(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = (e) => {
      setReadyState(WebSocket.OPEN);
      setReconnectCount(0);
      if (onOpen) onOpen(e);
    };
    
    socket.onmessage = (e) => {
      setLastMessage(e);
      if (onMessage) onMessage(e);
    };
    
    socket.onclose = (e) => {
      setReadyState(WebSocket.CLOSED);
      if (onClose) onClose(e);
      
      // Attempt to reconnect if not a normal closure and we haven't exceeded max attempts
      if (!e.wasClean && reconnectCount < reconnectAttempts) {
        setTimeout(() => {
          setReconnectCount((prev) => prev + 1);
          connect();
        }, reconnectInterval);
      }
    };
    
    socket.onerror = (e) => {
      if (onError) onError(e);
    };
    
    socketRef.current = socket;
    return socket;
  }, [onOpen, onMessage, onClose, onError, reconnectAttempts, reconnectCount, reconnectInterval]);
  
  // Initialize WebSocket connection on mount
  useEffect(() => {
    const socket = connect();
    
    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [connect]);
  
  // Send a message through the WebSocket
  const sendMessage = useCallback((data: string | ArrayBufferLike | Blob | ArrayBufferView) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(data);
      return true;
    }
    return false;
  }, []);
  
  return {
    lastMessage,
    readyState,
    sendMessage,
    reconnectCount,
  };
}
