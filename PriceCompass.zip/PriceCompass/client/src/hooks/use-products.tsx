import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { ProductWithPrices } from "@shared/schema";
import { useWebSocket } from "./use-websocket";
import { apiRequest } from "@/lib/queryClient";

interface UseProductsOptions {
  query?: string;
  limit?: number;
  sortBy?: string;
  filters?: {
    categories?: string[];
    brands?: string[];
    genders?: string[];
    sizes?: string[];
    priceRange?: [number, number];
  };
}

export function useProducts(options: UseProductsOptions = {}) {
  const { query = "", limit = 20, sortBy = "popular", filters = {} } = options;
  const [pricesUpdatedAt, setPricesUpdatedAt] = useState<Date | null>(null);
  const queryClient = useQueryClient();
  
  // Build query parameters
  const queryParams = new URLSearchParams();
  if (query) queryParams.append("q", query);
  if (limit) queryParams.append("limit", limit.toString());
  if (sortBy) queryParams.append("sortBy", sortBy);
  
  // Add filters to query params
  if (filters.categories?.length) {
    filters.categories.forEach(cat => queryParams.append("category", cat));
  }
  if (filters.brands?.length) {
    filters.brands.forEach(brand => queryParams.append("brand", brand));
  }
  if (filters.genders?.length) {
    filters.genders.forEach(gender => queryParams.append("gender", gender));
  }
  if (filters.sizes?.length) {
    filters.sizes.forEach(size => queryParams.append("size", size));
  }
  if (filters.priceRange) {
    queryParams.append("minPrice", filters.priceRange[0].toString());
    queryParams.append("maxPrice", filters.priceRange[1].toString());
  }
  
  // Fetch products using the query parameters
  const queryString = queryParams.toString();
  const { data, isLoading, error } = useQuery<ProductWithPrices[]>({
    queryKey: [`/api/products?${queryString}`],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Listen for price updates via WebSocket
  const { lastMessage, sendMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage.data);
        if (data.type === 'PRICE_UPDATE') {
          // Invalidate the query to refetch products with updated prices
          queryClient.invalidateQueries({ queryKey: [`/api/products`] });
          setPricesUpdatedAt(new Date());
        }
      } catch (e) {
        console.error('Failed to parse WebSocket message:', e);
      }
    }
  }, [lastMessage, queryClient]);

  // Mutation to refresh prices
  const refreshMutation = useMutation({
    mutationFn: async () => {
      // Send a message to the server to request a price refresh
      sendMessage(JSON.stringify({ type: 'REFRESH_PRICES' }));
      // Also make an API call to refresh prices
      await apiRequest('POST', '/api/prices/refresh', {});
      // Update the timestamp
      setPricesUpdatedAt(new Date());
    },
    onSuccess: () => {
      // Invalidate queries to refetch with new prices
      queryClient.invalidateQueries({ queryKey: [`/api/products`] });
    },
  });

  // Helper function to refresh prices
  const refreshPrices = async () => {
    await refreshMutation.mutateAsync();
  };

  return {
    products: data || [],
    isLoading,
    error,
    pricesUpdatedAt,
    refreshPrices,
    isRefreshing: refreshMutation.isPending,
  };
}
