import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Category } from "@shared/schema";

export function useCategories() {
  const { data, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    staleTime: Infinity, // Categories don't change often
  });

  // Default to empty array if data is not available
  const categories = data || [];

  return {
    categories,
    isLoading,
    error,
  };
}
