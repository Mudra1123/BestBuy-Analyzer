import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ProductWithPrices } from "@/store/types";
import { apiRequest } from "@/lib/queryClient";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb";
import { Badge } from "@/components/ui/badge";
import RealTimePriceComparison from "@/components/real-time-price-comparison";
import { ComprehensiveComparison } from "@/components/comprehensive-comparison";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star, Home, ChevronRight } from "lucide-react";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:slug");
  const slug = params?.slug;

  const { data: product, isLoading, error } = useQuery<ProductWithPrices>({
    queryKey: ["/api/products", slug],
    queryFn: async () => {
      const response = await apiRequest<ProductWithPrices>({ 
        url: `/api/products/${slug}` 
      });
      return response as ProductWithPrices;
    },
    enabled: !!slug,
  });

  // Fetch comprehensive comparison data
  const { data: comparison, isLoading: comparisonLoading } = useQuery({
    queryKey: ["/api/comparison/product", slug],
    queryFn: async () => {
      const response = await apiRequest({ 
        url: `/api/comparison/product/${slug}` 
      });
      return response;
    },
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <Skeleton className="h-[500px] w-full rounded-lg" />
          </div>
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/3" />
            <div className="space-y-2 mt-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
            <Skeleton className="h-[300px] w-full mt-8" />
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container py-12">
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold mb-4">Error Loading Product</h2>
          <p className="text-gray-600 mb-6">There was a problem loading this product. Please try again later.</p>
          <Button asChild variant="default">
            <a href="/">Return to Home</a>
          </Button>
        </div>
      </div>
    );
  }

  const productData = product as ProductWithPrices;

  if (!productData) {
    return (
      <div className="container py-12">
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <p className="text-gray-600 mb-6">We couldn't find the product you're looking for.</p>
          <Button asChild variant="default">
            <a href="/">Return to Home</a>
          </Button>
        </div>
      </div>
    );
  }

  // Find if there are any deals (price variations between platforms)
  const hasPriceVariations = productData.prices.length > 1 && 
    new Set(productData.prices.map(p => p.amount)).size > 1;

  // Get price range
  const prices = productData.prices.map(price => 
    typeof price.amount === 'number' ? price.amount : parseFloat(String(price.amount))
  );
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const hasPriceRange = minPrice !== maxPrice;

  // Format price nicely
  const formatPrice = (amount: number) => {
    // Format based on size of the amount
    if (amount >= 1000) {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(amount);
    } else {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(amount);
    }
  };

  return (
    <div className="container py-8">
      {/* Breadcrumbs */}
      <Breadcrumb className="mb-6">
        <BreadcrumbItem>
          <BreadcrumbLink href="/">
            <Home className="h-4 w-4 mr-1" />
            Home
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink href={`/search?category=${productData.category.slug}`}>
            {productData.category.name}
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink>{productData.name}</BreadcrumbLink>
        </BreadcrumbItem>
      </Breadcrumb>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Product Image */}
        <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden border shadow-sm">
          <img
            src={productData.imageUrl || "https://placehold.co/600x400?text=No+Image"}
            alt={productData.name}
            className="w-full h-auto object-cover aspect-square"
          />
        </div>

        {/* Product Info */}
        <div>
          <div className="pb-6 border-b">
            <div className="flex items-center justify-between mb-2">
              <Badge 
                variant="outline" 
                className="font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800"
              >
                {productData.brand.name}
              </Badge>
              {hasPriceVariations && (
                <Badge variant="default" className="bg-green-600">
                  Price Variations Available
                </Badge>
              )}
            </div>
            <h1 className="text-3xl font-bold mb-2">{productData.name}</h1>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < Math.floor(productData.rating ? parseFloat(String(productData.rating)) : 0)
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {productData.rating} ({productData.reviewCount} reviews)
              </span>
            </div>
            <div className="text-2xl font-bold mb-2">
              {hasPriceRange ? (
                <span>
                  {formatPrice(minPrice)} - {formatPrice(maxPrice)}
                </span>
              ) : (
                <span>{formatPrice(minPrice)}</span>
              )}
            </div>
          </div>

          <div className="py-6 border-b">
            <h2 className="text-xl font-semibold mb-2">Description</h2>
            <p className="text-gray-700 dark:text-gray-300">
              {productData.description || "No description available."}
            </p>
          </div>

          <div className="py-6">
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className="bg-gray-100 dark:bg-gray-800">
                Category: {productData.category.name}
              </Badge>
              {productData.gender && (
                <Badge variant="outline" className="bg-gray-100 dark:bg-gray-800">
                  Gender: {productData.gender.name}
                </Badge>
              )}
              <Badge variant="outline" className="bg-gray-100 dark:bg-gray-800">
                Brand: {productData.brand.name}
              </Badge>
            </div>
          </div>

          {/* Comprehensive Comparison */}
          <div className="mt-8">
            <Tabs defaultValue="comparison" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="comparison">Smart Comparison</TabsTrigger>
                <TabsTrigger value="prices">Live Prices</TabsTrigger>
              </TabsList>
              
              <TabsContent value="comparison">
                {comparisonLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-32 w-full" />
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Skeleton className="h-64 w-full" />
                      <Skeleton className="h-64 w-full" />
                      <Skeleton className="h-64 w-full" />
                    </div>
                  </div>
                ) : comparison ? (
                  <ComprehensiveComparison comparison={comparison} />
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-600">Comparison data unavailable</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="prices">
                {productData.prices.length > 0 ? (
                  <RealTimePriceComparison
                    productId={productData.id}
                    initialPrices={productData.prices}
                  />
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-600">No price data available</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}