import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { useQuery } from "@tanstack/react-query";
import FilterSidebar from "@/components/filter-sidebar";
import ProductCard from "@/components/product-card";
import PriceRefreshIndicator from "@/components/price-refresh-indicator";
import { useProducts } from "@/hooks/use-products";
import { useWebSocket } from "@/hooks/use-websocket";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Icons } from "@/components/price-comparison";

type SortOption = "price_asc" | "price_desc" | "discount" | "popular";

export default function SearchResults() {
  const search = useSearch();
  const queryParams = new URLSearchParams(search);
  const searchQuery = queryParams.get("q") || "";
  const [, setLocation] = useLocation();
  
  const [sortBy, setSortBy] = useState<SortOption>("price_asc");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeFilters, setActiveFilters] = useState({
    categories: [] as string[],
    brands: [] as string[],
    genders: [] as string[],
    sizes: [] as string[],
    priceRange: [0, 10000] as [number, number],
  });

  // Get products with websocket updates for real-time prices
  const { products, isLoading, error, pricesUpdatedAt, refreshPrices } = useProducts({
    query: searchQuery,
    filters: activeFilters,
    sortBy,
  });

  // Listen for real-time price updates via WebSocket
  const { lastMessage } = useWebSocket();

  // Handle filter changes
  const handleFilterChange = (filters: typeof activeFilters) => {
    setActiveFilters(filters);
  };

  // Clear all filters
  const clearFilters = () => {
    setActiveFilters({
      categories: [],
      brands: [],
      genders: [],
      sizes: [],
      priceRange: [0, 10000],
    });
  };

  // Change sort order
  const handleSortChange = (value: string) => {
    setSortBy(value as SortOption);
  };

  // Calculate time since last update
  const getTimeSinceUpdate = () => {
    if (!pricesUpdatedAt) return "Never";
    
    const now = new Date();
    const diff = Math.floor((now.getTime() - pricesUpdatedAt.getTime()) / 1000 / 60);
    
    if (diff < 1) return "Just now";
    if (diff === 1) return "1 minute ago";
    return `${diff} minutes ago`;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Filters Sidebar */}
        <FilterSidebar
          activeFilters={activeFilters}
          onChange={handleFilterChange}
          onClearAll={clearFilters}
        />
        
        {/* Results Content */}
        <div className="lg:w-3/4 xl:w-4/5">
          {/* Results Header */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-4 mb-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h1 className="text-xl font-bold text-gray-900">Results for "{searchQuery}"</h1>
                <p className="text-sm text-gray-500">
                  Found {isLoading ? "..." : products.length} products across 3 websites
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <span className="text-sm text-gray-600">Sort by:</span>
                <Select value={sortBy} onValueChange={handleSortChange}>
                  <SelectTrigger className="border border-gray-300 rounded-md bg-white text-gray-700 py-1 px-3 h-8 text-sm">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="price_asc">Price: Low to High</SelectItem>
                      <SelectItem value="price_desc">Price: High to Low</SelectItem>
                      <SelectItem value="discount">Highest Discount</SelectItem>
                      <SelectItem value="popular">Popularity</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
                <div className="flex border border-gray-200 rounded-md overflow-hidden">
                  <button 
                    className={`p-2 ${viewMode === "grid" ? "bg-primary text-white" : "bg-white text-gray-500 hover:text-primary"} focus:outline-none`}
                    onClick={() => setViewMode("grid")}
                  >
                    <Icons.Grid className="h-4 w-4" />
                  </button>
                  <button 
                    className={`p-2 ${viewMode === "list" ? "bg-primary text-white" : "bg-white text-gray-500 hover:text-primary"} focus:outline-none`}
                    onClick={() => setViewMode("list")}
                  >
                    <Icons.List className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {/* Refresh Indicator */}
          <PriceRefreshIndicator 
            lastUpdated={getTimeSinceUpdate()}
            onRefresh={refreshPrices}
          />
          
          {/* Results Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6 mb-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                  <Skeleton className="w-full h-48" />
                  <div className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <div className="space-y-3 mb-4">
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                    </div>
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="bg-red-50 p-4 rounded-lg text-red-500">
              Error loading products: {error.toString()}
            </div>
          ) : products.length === 0 ? (
            <div className="bg-gray-50 p-8 rounded-lg text-center">
              <Icons.AlertCircle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-medium text-gray-700 mb-2">No products found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filter criteria
              </p>
            </div>
          ) : (
            <div className={`grid ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3" : "grid-cols-1"} gap-6 mb-8`}>
              {products.map((product) => (
                <ProductCard key={product.id} product={product} viewMode={viewMode} />
              ))}
            </div>
          )}
          
          {/* Pagination - only show if we have products */}
          {products.length > 0 && (
            <div className="flex justify-center mt-8">
              <nav className="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <a href="#" className="inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                  <Icons.ChevronLeft className="h-4 w-4" />
                </a>
                <a href="#" className="inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                  1
                </a>
                <a href="#" className="inline-flex items-center px-4 py-2 border border-gray-300 bg-primary text-sm font-medium text-white">
                  2
                </a>
                <a href="#" className="inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                  3
                </a>
                <span className="inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">
                  ...
                </span>
                <a href="#" className="inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                  8
                </a>
                <a href="#" className="inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                  <Icons.ChevronRight className="h-4 w-4" />
                </a>
              </nav>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
