import { useState } from "react";
import { useLocation } from "wouter";
import SearchBar from "@/components/search-bar";
import PopularCategories from "@/components/popular-categories";
import TrendingDeals from "@/components/trending-deals";

export default function Home() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      setLocation(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <section className="py-16 text-center max-w-4xl mx-auto">
        <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
          Find the Best Deals Across Sites
        </h1>
        <p className="text-lg text-gray-600 mb-8">
          Compare prices from Amazon, Flipkart, Myntra and more - all in one place.
        </p>
        
        {/* Main Search Bar */}
        <SearchBar 
          onSearch={handleSearch} 
          placeholder="Search for products, brands, or categories..."
          className="max-w-2xl mx-auto mb-8"
        />
        
        {/* Popular Categories */}
        <PopularCategories />
        
        {/* Trending Deals */}
        <TrendingDeals />
      </section>
    </div>
  );
}
