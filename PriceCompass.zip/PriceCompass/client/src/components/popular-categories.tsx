import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useCategories } from "@/hooks/use-categories";
import { Skeleton } from "@/components/ui/skeleton";
import { Icons } from "@/components/price-comparison";

export default function PopularCategories() {
  const { categories, isLoading, error } = useCategories();

  // Render loading state
  if (isLoading) {
    return (
      <div className="mt-16">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Popular Categories</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 max-w-5xl mx-auto">
          {Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg shadow-sm">
              <div className="flex items-center justify-center mb-3">
                <Skeleton className="w-16 h-16 rounded-full" />
              </div>
              <Skeleton className="h-4 w-20 mx-auto" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="mt-16">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Popular Categories</h2>
        <div className="bg-red-50 p-4 rounded-lg text-red-600 text-center">
          Failed to load categories
        </div>
      </div>
    );
  }

  // Map category slug to icon
  const getCategoryIcon = (iconName: string | null | undefined) => {
    if (!iconName) return <Icons.Tag className="h-6 w-6" />;
    
    switch (iconName) {
      case "ri-t-shirt-line":
        return <Icons.TShirt className="h-6 w-6" />;
      case "ri-smartphone-line":
        return <Icons.Smartphone className="h-6 w-6" />;
      case "ri-home-line":
        return <Icons.Home className="h-6 w-6" />;
      case "ri-footprint-line":
        return <Icons.Footprints className="h-6 w-6" />;
      case "ri-computer-line":
        return <Icons.Laptop className="h-6 w-6" />;
      case "ri-gamepad-line":
        return <Icons.Gamepad className="h-6 w-6" />;
      default:
        return <Icons.Tag className="h-6 w-6" />;
    }
  };

  return (
    <div className="mt-16">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Popular Categories</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 max-w-5xl mx-auto">
        {categories.map((category) => (
          <Link
            key={category.id}
            href={`/search?category=${category.slug}`}
            className="bg-gray-50 p-4 rounded-lg shadow-sm hover:shadow-md transition cursor-pointer group"
          >
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 group-hover:bg-primary/5 transition">
              <span className="text-2xl text-primary">
                {getCategoryIcon(category.icon)}
              </span>
            </div>
            <h3 className="text-sm font-medium text-gray-700 text-center">{category.name}</h3>
          </Link>
        ))}
      </div>
    </div>
  );
}
