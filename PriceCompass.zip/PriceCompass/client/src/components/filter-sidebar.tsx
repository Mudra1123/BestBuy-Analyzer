import { useState, useEffect } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { useCategories } from "@/hooks/use-categories";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Icons } from "@/components/price-comparison";

type FilterSidebarProps = {
  activeFilters: {
    categories: string[];
    brands: string[];
    genders: string[];
    sizes: string[];
    priceRange: [number, number];
  };
  onChange: (filters: any) => void;
  onClearAll: () => void;
};

export default function FilterSidebar({ activeFilters, onChange, onClearAll }: FilterSidebarProps) {
  // State for each filter section
  const [categoryFilters, setCategoryFilters] = useState<string[]>(activeFilters.categories);
  const [brandFilters, setBrandFilters] = useState<string[]>(activeFilters.brands);
  const [genderFilters, setGenderFilters] = useState<string[]>(activeFilters.genders);
  const [sizeFilters, setSizeFilters] = useState<string[]>(activeFilters.sizes);
  const [priceRange, setPriceRange] = useState<[number, number]>(activeFilters.priceRange);

  // Fetch data
  const { categories, isLoading: categoriesLoading } = useCategories();
  
  const { data: brands, isLoading: brandsLoading } = useQuery({
    queryKey: ['/api/brands'],
    staleTime: Infinity,
  });

  const { data: genders, isLoading: gendersLoading } = useQuery({
    queryKey: ['/api/genders'],
    staleTime: Infinity,
  });

  const { data: sizes, isLoading: sizesLoading } = useQuery({
    queryKey: ['/api/sizes'],
    staleTime: Infinity,
  });

  // Update parent component with filter changes
  useEffect(() => {
    onChange({
      categories: categoryFilters,
      brands: brandFilters,
      genders: genderFilters,
      sizes: sizeFilters,
      priceRange,
    });
  }, [categoryFilters, brandFilters, genderFilters, sizeFilters, priceRange, onChange]);

  // Handler for category checkbox changes
  const handleCategoryChange = (categorySlug: string, checked: boolean) => {
    if (checked) {
      setCategoryFilters([...categoryFilters, categorySlug]);
    } else {
      setCategoryFilters(categoryFilters.filter(slug => slug !== categorySlug));
    }
  };

  // Handler for brand checkbox changes
  const handleBrandChange = (brandSlug: string, checked: boolean) => {
    if (checked) {
      setBrandFilters([...brandFilters, brandSlug]);
    } else {
      setBrandFilters(brandFilters.filter(slug => slug !== brandSlug));
    }
  };

  // Handler for gender checkbox changes
  const handleGenderChange = (genderSlug: string, checked: boolean) => {
    if (checked) {
      setGenderFilters([...genderFilters, genderSlug]);
    } else {
      setGenderFilters(genderFilters.filter(slug => slug !== genderSlug));
    }
  };

  // Handler for size button clicks
  const handleSizeToggle = (size: string) => {
    if (sizeFilters.includes(size)) {
      setSizeFilters(sizeFilters.filter(s => s !== size));
    } else {
      setSizeFilters([...sizeFilters, size]);
    }
  };

  // Handler for price range slider
  const handlePriceRangeChange = (value: number[]) => {
    setPriceRange([value[0], value[1]]);
  };

  // Clear all filters
  const handleClearAll = () => {
    setCategoryFilters([]);
    setBrandFilters([]);
    setGenderFilters([]);
    setSizeFilters([]);
    setPriceRange([0, 10000]);
    onClearAll();
  };

  return (
    <div className="lg:w-1/4 xl:w-1/5">
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 sticky top-20 overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center">
          <h2 className="font-semibold text-gray-900">Filters</h2>
          <Button 
            variant="ghost" 
            className="text-primary text-sm font-medium h-auto p-1" 
            onClick={handleClearAll}
          >
            Clear All
          </Button>
        </div>
        
        <Accordion type="multiple" defaultValue={["category", "brand", "gender", "size", "price"]}>
          {/* Category Filter */}
          <AccordionItem value="category" className="border-b border-gray-100">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium">Category</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4 pt-0 space-y-2">
              {categoriesLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-2">
                    <Skeleton className="h-4 w-4 rounded" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                ))
              ) : (
                categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`category-${category.id}`}
                      checked={categoryFilters.includes(category.slug)}
                      onCheckedChange={(checked) => handleCategoryChange(category.slug, !!checked)}
                    />
                    <label 
                      htmlFor={`category-${category.id}`}
                      className="text-gray-700 text-sm cursor-pointer"
                    >
                      {category.name}
                    </label>
                  </div>
                ))
              )}
            </AccordionContent>
          </AccordionItem>
          
          {/* Brand Filter */}
          <AccordionItem value="brand" className="border-b border-gray-100">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium">Brand</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4 pt-0 space-y-2">
              {brandsLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-2">
                    <Skeleton className="h-4 w-4 rounded" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                ))
              ) : (
                brands?.map((brand: any) => (
                  <div key={brand.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`brand-${brand.id}`}
                      checked={brandFilters.includes(brand.slug)}
                      onCheckedChange={(checked) => handleBrandChange(brand.slug, !!checked)}
                    />
                    <label 
                      htmlFor={`brand-${brand.id}`}
                      className="text-gray-700 text-sm cursor-pointer"
                    >
                      {brand.name}
                    </label>
                  </div>
                )) || [
                  'Levi\'s', 'H&M', 'Zara', 'Nike', 'Adidas'
                ].map((brand, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`brand-${index}`}
                      checked={brandFilters.includes(brand.toLowerCase())}
                      onCheckedChange={(checked) => handleBrandChange(brand.toLowerCase(), !!checked)}
                    />
                    <label 
                      htmlFor={`brand-${index}`}
                      className="text-gray-700 text-sm cursor-pointer"
                    >
                      {brand}
                    </label>
                  </div>
                ))
              )}
            </AccordionContent>
          </AccordionItem>
          
          {/* Gender Filter */}
          <AccordionItem value="gender" className="border-b border-gray-100">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium">Gender</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4 pt-0 space-y-2">
              {gendersLoading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-2">
                    <Skeleton className="h-4 w-4 rounded" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                ))
              ) : (
                genders?.map((gender: any) => (
                  <div key={gender.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`gender-${gender.id}`}
                      checked={genderFilters.includes(gender.slug)}
                      onCheckedChange={(checked) => handleGenderChange(gender.slug, !!checked)}
                    />
                    <label 
                      htmlFor={`gender-${gender.id}`}
                      className="text-gray-700 text-sm cursor-pointer"
                    >
                      {gender.name}
                    </label>
                  </div>
                )) || [
                  'Men', 'Women', 'Unisex'
                ].map((gender, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`gender-${index}`}
                      checked={genderFilters.includes(gender.toLowerCase())}
                      onCheckedChange={(checked) => handleGenderChange(gender.toLowerCase(), !!checked)}
                    />
                    <label 
                      htmlFor={`gender-${index}`}
                      className="text-gray-700 text-sm cursor-pointer"
                    >
                      {gender}
                    </label>
                  </div>
                ))
              )}
            </AccordionContent>
          </AccordionItem>
          
          {/* Size Filter */}
          <AccordionItem value="size" className="border-b border-gray-100">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium">Size</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4 pt-0">
              <div className="flex flex-wrap gap-2">
                {sizesLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className="h-10 w-10 rounded-md" />
                  ))
                ) : (
                  sizes?.map((size: any) => (
                    <Button
                      key={size.id}
                      variant={sizeFilters.includes(size.name) ? "default" : "outline"}
                      className={`min-w-10 h-10 p-0 ${sizeFilters.includes(size.name) ? 'bg-primary text-white' : ''}`}
                      onClick={() => handleSizeToggle(size.name)}
                    >
                      {size.name}
                    </Button>
                  )) || [
                    'XS', 'S', 'M', 'L', 'XL', 'XXL'
                  ].map((size) => (
                    <Button
                      key={size}
                      variant={sizeFilters.includes(size) ? "default" : "outline"}
                      className={`min-w-10 h-10 p-0 ${sizeFilters.includes(size) ? 'bg-primary text-white' : ''}`}
                      onClick={() => handleSizeToggle(size)}
                    >
                      {size}
                    </Button>
                  ))
                )}
              </div>
            </AccordionContent>
          </AccordionItem>
          
          {/* Price Range Filter */}
          <AccordionItem value="price">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <span className="font-medium">Price Range</span>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4 pt-0">
              <div className="space-y-4">
                <div className="pt-4">
                  <Slider
                    defaultValue={[priceRange[0], priceRange[1]]}
                    min={0}
                    max={10000}
                    step={100}
                    value={[priceRange[0], priceRange[1]]}
                    onValueChange={handlePriceRangeChange}
                  />
                </div>
                <div className="flex justify-between">
                  <div className="border border-gray-300 rounded py-1 px-2 text-sm text-gray-700">
                    ₹{priceRange[0]}
                  </div>
                  <div className="border border-gray-300 rounded py-1 px-2 text-sm text-gray-700">
                    ₹{priceRange[1]}
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}
