import { Link } from "wouter";
import { Icons } from "@/components/price-comparison";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100 mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Icons.PriceTag className="h-5 w-5 text-primary" />
              <span className="font-bold text-lg text-gray-900">BestBuy Analyzer</span>
            </div>
            <p className="text-gray-600 text-sm mb-4">
              Compare prices across top e-commerce platforms and find the best deals on your favorite products.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-500 hover:text-primary">
                <Icons.Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-500 hover:text-primary">
                <Icons.Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-500 hover:text-primary">
                <Icons.Instagram className="h-5 w-5" />
              </Link>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-600 hover:text-primary text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/search?category=clothing" className="text-gray-600 hover:text-primary text-sm">
                  Categories
                </Link>
              </li>
              <li>
                <Link href="#how-it-works" className="text-gray-600 hover:text-primary text-sm">
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="/search?sort=discount" className="text-gray-600 hover:text-primary text-sm">
                  Top Deals
                </Link>
              </li>
              <li>
                <Link href="#price-alerts" className="text-gray-600 hover:text-primary text-sm">
                  Price Alerts
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#blog" className="text-gray-600 hover:text-primary text-sm">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#help" className="text-gray-600 hover:text-primary text-sm">
                  Help Center
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-gray-600 hover:text-primary text-sm">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#about" className="text-gray-600 hover:text-primary text-sm">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#careers" className="text-gray-600 hover:text-primary text-sm">
                  Careers
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-4">Newsletter</h3>
            <p className="text-gray-600 text-sm mb-4">
              Subscribe to get notified about product launches, special offers and news.
            </p>
            <div className="flex">
              <Input
                type="email"
                placeholder="Enter your email"
                className="rounded-r-none border-r-0 text-sm"
              />
              <Button className="rounded-l-none text-sm">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm">© {new Date().getFullYear()} BestBuy Analyzer. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="#privacy" className="text-gray-600 hover:text-primary text-sm">
              Privacy Policy
            </Link>
            <Link href="#terms" className="text-gray-600 hover:text-primary text-sm">
              Terms of Service
            </Link>
            <Link href="#cookies" className="text-gray-600 hover:text-primary text-sm">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
