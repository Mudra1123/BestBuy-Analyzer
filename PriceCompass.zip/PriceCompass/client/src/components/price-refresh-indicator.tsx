import { Icons } from "@/components/price-comparison";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface PriceRefreshIndicatorProps {
  lastUpdated: string;
  onRefresh: () => Promise<void>;
}

export default function PriceRefreshIndicator({ lastUpdated, onRefresh }: PriceRefreshIndicatorProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onRefresh();
    } catch (error) {
      console.error("Error refreshing prices:", error);
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="flex items-center justify-between bg-blue-50 rounded-lg p-3 mb-6">
      <div className="flex items-center text-sm text-blue-700">
        <Icons.RefreshCw className="mr-2 h-4 w-4" />
        <span>Prices last updated: <strong>{lastUpdated}</strong></span>
      </div>
      <Button 
        variant="ghost" 
        size="sm" 
        className="text-blue-700 hover:text-blue-800 text-sm font-medium h-auto p-1" 
        onClick={handleRefresh}
        disabled={isRefreshing}
      >
        <span>Refresh Now</span>
        <Icons.RefreshCw className={`ml-1 h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
      </Button>
    </div>
  );
}
