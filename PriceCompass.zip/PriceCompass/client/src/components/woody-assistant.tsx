import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, SendHorizonal, Bot } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Message {
  type: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export default function WoodyAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      type: "assistant",
      content: "Hi there! I'm Woody, your shopping assistant. How can I help with your shopping today?",
      timestamp: new Date(),
    },
  ]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      type: "user",
      content: question,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setQuestion("");
    setLoading(true);
    
    try {
      // Send question to API
      const response = await apiRequest<{success: boolean; answer: string}>({
        method: "POST",
        url: "/api/assistant/woody",
        data: { question }
      });
      
      // Add assistant response
      const assistantMessage: Message = {
        type: "assistant",
        content: response && typeof response === 'object' && 'answer' in response ? 
          response.answer : 
          "I couldn't find an answer to that.",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Failed to get response from Woody:", error);
      
      // Add error message
      const errorMessage: Message = {
        type: "assistant",
        content: "Sorry, I'm having trouble right now. Please try again later.",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {!isOpen ? (
        <Button 
          onClick={() => setIsOpen(true)}
          className="rounded-full w-14 h-14 shadow-lg bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700"
        >
          <Bot size={24} />
        </Button>
      ) : (
        <Card className="w-80 sm:w-96 shadow-lg border-2 border-blue-100 dark:border-blue-900">
          <CardHeader className="bg-gradient-to-r from-indigo-500 to-blue-600 text-white py-3">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border-2 border-white">
                <AvatarImage src="/woody-avatar.png" alt="Woody" />
                <AvatarFallback className="bg-blue-700 text-white">W</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-lg">Woody</CardTitle>
                <p className="text-xs text-blue-100">Shopping Assistant</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setIsOpen(false)}
              className="absolute top-2 right-2 text-white hover:bg-blue-700 h-8 w-8 p-0"
            >
              ✕
            </Button>
          </CardHeader>
          
          <ScrollArea className="h-[320px] p-4">
            <CardContent className="px-0 pt-4 pb-0">
              {messages.map((message, i) => (
                <div
                  key={i}
                  className={`mb-4 ${
                    message.type === "user" ? "text-right" : "text-left"
                  }`}
                >
                  <div
                    className={`inline-block rounded-lg px-4 py-2 max-w-[85%] ${
                      message.type === "user"
                        ? "bg-blue-500 text-white"
                        : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                    }`}
                  >
                    {message.content}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-center my-2">
                  <Loader2 className="h-6 w-6 animate-spin text-blue-500" />
                </div>
              )}
            </CardContent>
          </ScrollArea>
          
          <CardFooter className="border-t p-3">
            <form onSubmit={handleSubmit} className="flex w-full gap-2">
              <Input
                type="text"
                placeholder="Ask Woody a question..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                disabled={loading}
                className="flex-1"
              />
              <Button type="submit" size="icon" disabled={loading}>
                <SendHorizonal className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}