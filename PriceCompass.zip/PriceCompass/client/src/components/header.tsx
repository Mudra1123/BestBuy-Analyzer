import { useState } from "react";
import { Link } from "wouter";
import { useMobile } from "@/hooks/use-mobile";
import { Icons } from "@/components/price-comparison";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function Header() {
  const isMobile = useMobile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <Icons.PriceTag className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl text-gray-900">BestBuy Analyzer</span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-900 font-medium hover:text-primary transition">
              Home
            </Link>
            <Link href="/search?category=clothing" className="text-gray-600 hover:text-primary transition">
              Categories
            </Link>
            <Link href="/search?sort=discount" className="text-gray-600 hover:text-primary transition">
              Deals
            </Link>
            <Link href="#about" className="text-gray-600 hover:text-primary transition">
              About
            </Link>
          </nav>
          
          {/* Login Button */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="hidden sm:flex items-center text-gray-600 hover:text-primary">
              <Icons.User className="mr-1 h-4 w-4" />
              <span>Login</span>
            </Button>
            
            {/* Mobile menu button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden text-gray-600 hover:text-primary" 
              onClick={toggleMenu}
            >
              <Icons.Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      <div className={cn("md:hidden", isMenuOpen ? "block" : "hidden")}>
        <div className="px-2 pt-2 pb-3 space-y-1 bg-gray-50">
          <Link href="/" className="block px-3 py-2 text-base font-medium text-gray-900 rounded-md">
            Home
          </Link>
          <Link href="/search?category=clothing" className="block px-3 py-2 text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-100 rounded-md">
            Categories
          </Link>
          <Link href="/search?sort=discount" className="block px-3 py-2 text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-100 rounded-md">
            Deals
          </Link>
          <Link href="#about" className="block px-3 py-2 text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-100 rounded-md">
            About
          </Link>
          <Link href="#login" className="block px-3 py-2 text-base font-medium text-gray-600 hover:text-primary hover:bg-gray-100 rounded-md">
            Login
          </Link>
        </div>
      </div>
    </header>
  );
}
