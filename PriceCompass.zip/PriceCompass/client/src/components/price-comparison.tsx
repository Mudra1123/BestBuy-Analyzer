import { cn } from "@/lib/utils";
import { Price } from "@shared/schema";
import * as LucideIcons from "lucide-react";

export const Icons = {
  PriceTag: LucideIcons.Tag,
  User: LucideIcons.User,
  Search: LucideIcons.Search,
  Menu: LucideIcons.Menu,
  Grid: LucideIcons.LayoutGrid,
  List: LucideIcons.List,
  Star: LucideIcons.Star,
  StarFill: LucideIcons.Star,
  StarHalf: LucideIcons.StarHalf,
  Heart: LucideIcons.Heart,
  HeartFill: LucideIcons.Heart,
  RefreshCw: LucideIcons.RefreshCw,
  Facebook: LucideIcons.Facebook,
  Twitter: LucideIcons.Twitter,
  Instagram: LucideIcons.Instagram,
  AlertCircle: LucideIcons.AlertCircle,
  ChevronLeft: LucideIcons.ChevronLeft,
  ChevronRight: LucideIcons.ChevronRight,
  ExternalLink: LucideIcons.ExternalLink,
  TShirt: LucideIcons.Shirt,
  Smartphone: LucideIcons.Smartphone,
  Home: LucideIcons.Home,
  Footprints: LucideIcons.Footprints,
  Laptop: LucideIcons.Laptop,
  Gamepad: LucideIcons.Gamepad,
  Tag: LucideIcons.Tag,
};

interface PriceComparisonProps {
  prices: Price[];
  className?: string;
}

export function PriceComparison({ prices, className }: PriceComparisonProps) {
  // Find the lowest and highest prices to calculate relative bar widths
  const pricesWithValues = prices.map(price => ({
    ...price,
    numericAmount: typeof price.amount === 'number' ? price.amount : parseFloat(price.amount),
  }));

  const lowestPrice = Math.min(...pricesWithValues.map(p => p.numericAmount));
  const highestPrice = Math.max(...pricesWithValues.map(p => p.numericAmount));
  
  // Calculate width for each price bar (lowest is shortest, highest is full width)
  const calculateWidth = (price: number) => {
    if (lowestPrice === highestPrice) return "100%";
    // Scale between 75% and 100% to make differences more visible
    const percentage = 75 + (25 * (price - lowestPrice) / (highestPrice - lowestPrice));
    return `${percentage}%`;
  };

  return (
    <div className={cn("space-y-3", className)}>
      {pricesWithValues.map((price) => (
        <div key={price.id} className="bg-gray-50 rounded-lg p-2">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <img src={price.platform.logoUrl} alt={price.platform.name} className="h-4 mr-2" />
              <span 
                className="font-semibold" 
                style={{ color: price.platform.colorCode || 'currentColor' }}
              >
                ₹{price.numericAmount.toFixed(0)}
              </span>
            </div>
            <a 
              href={price.url || "#"} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-sm text-primary hover:text-primary/90"
              onClick={(e) => e.stopPropagation()}
            >
              <Icons.ExternalLink className="h-4 w-4" />
            </a>
          </div>
          <div className="mt-1.5 relative w-full bg-gray-200 h-1 rounded-full overflow-hidden">
            <div 
              className="price-bar absolute left-0 top-0 h-full rounded-full" 
              style={{ 
                width: calculateWidth(price.numericAmount),
                backgroundColor: price.platform.colorCode || 'currentColor'
              }}
            ></div>
          </div>
        </div>
      ))}
    </div>
  );
}
