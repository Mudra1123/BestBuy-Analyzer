import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Star, 
  Truck, 
  Shield, 
  DollarSign, 
  Clock, 
  Award,
  ThumbsUp,
  Package,
  ArrowRight
} from "lucide-react";

interface ComparisonMetrics {
  price: number;
  rating: number;
  delivery: number;
  quality: number;
  returnPolicy: number;
  valueForMoney: number;
  overallScore: number;
}

interface PlatformComparison {
  platformId: number;
  platformName: string;
  platformSlug: string;
  colorCode: string;
  price: number;
  rating: number;
  reviewCount: number;
  deliveryTimeMin: number;
  deliveryTimeMax: number;
  shippingCost: number;
  returnPolicyDays: number;
  returnPolicyRating: number;
  customerServiceRating: number;
  qualityRating: number;
  valueForMoneyRating: number;
  deliveryExperienceRating: number;
  metrics: ComparisonMetrics;
  isAvailable: boolean;
  url: string;
}

interface ProductComparison {
  platforms: PlatformComparison[];
  bestPrice: PlatformComparison;
  bestRating: PlatformComparison;
  fastestDelivery: PlatformComparison;
  bestQuality: PlatformComparison;
  bestValue: PlatformComparison;
  recommended: PlatformComparison;
  recommendationReason: string;
}

interface ComprehensiveComparisonProps {
  comparison: ProductComparison;
}

const MetricCard = ({ icon: Icon, title, value, description, color = "blue" }: {
  icon: React.ElementType;
  title: string;
  value: string | number;
  description?: string;
  color?: string;
}) => (
  <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
    <div className={`p-2 rounded-full bg-${color}-100 dark:bg-${color}-900`}>
      <Icon className={`h-4 w-4 text-${color}-600 dark:text-${color}-400`} />
    </div>
    <div className="flex-1">
      <p className="font-medium text-sm">{title}</p>
      <p className="text-2xl font-bold">{value}</p>
      {description && <p className="text-xs text-gray-600 dark:text-gray-400">{description}</p>}
    </div>
  </div>
);

const PlatformCard = ({ platform, isRecommended, badges }: {
  platform: PlatformComparison;
  isRecommended?: boolean;
  badges?: string[];
}) => (
  <Card className={`relative ${isRecommended ? 'ring-2 ring-blue-500 shadow-lg' : ''}`}>
    {isRecommended && (
      <div className="absolute -top-2 left-4 bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-medium">
        Recommended
      </div>
    )}
    <CardHeader className="pb-3">
      <div className="flex items-center justify-between">
        <CardTitle 
          className="text-lg flex items-center space-x-2"
          style={{ color: platform.colorCode }}
        >
          <span>{platform.platformName}</span>
        </CardTitle>
        <div className="text-right">
          <p className="text-2xl font-bold">₹{platform.price.toLocaleString()}</p>
          {platform.shippingCost > 0 && (
            <p className="text-xs text-gray-500">+ ₹{platform.shippingCost} shipping</p>
          )}
        </div>
      </div>
      {badges && badges.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {badges.map((badge, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {badge}
            </Badge>
          ))}
        </div>
      )}
    </CardHeader>
    <CardContent className="space-y-4">
      {/* Rating and Reviews */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-1">
          <Star className="h-4 w-4 text-yellow-400 fill-current" />
          <span className="font-medium">{platform.rating.toFixed(1)}</span>
          <span className="text-sm text-gray-600">
            ({platform.reviewCount.toLocaleString()} reviews)
          </span>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="flex items-center space-x-1">
          <Truck className="h-3 w-3 text-gray-500" />
          <span>{platform.deliveryTimeMin}-{platform.deliveryTimeMax} days</span>
        </div>
        <div className="flex items-center space-x-1">
          <Shield className="h-3 w-3 text-gray-500" />
          <span>{platform.returnPolicyDays} day returns</span>
        </div>
        <div className="flex items-center space-x-1">
          <Award className="h-3 w-3 text-gray-500" />
          <span>Quality: {platform.qualityRating.toFixed(1)}/5</span>
        </div>
        <div className="flex items-center space-x-1">
          <ThumbsUp className="h-3 w-3 text-gray-500" />
          <span>Value: {platform.valueForMoneyRating.toFixed(1)}/5</span>
        </div>
      </div>

      {/* Overall Score */}
      <div>
        <div className="flex justify-between text-sm mb-1">
          <span>Overall Score</span>
          <span className="font-medium">{(platform.metrics.overallScore * 100).toFixed(0)}%</span>
        </div>
        <Progress value={platform.metrics.overallScore * 100} className="h-2" />
      </div>

      {/* Action Button */}
      <button 
        className="w-full py-2 px-4 rounded-lg font-medium text-white transition-colors"
        style={{ backgroundColor: platform.colorCode }}
        onClick={() => window.open(platform.url, '_blank')}
      >
        View on {platform.platformName}
        <ArrowRight className="h-4 w-4 ml-2 inline" />
      </button>
    </CardContent>
  </Card>
);

export function ComprehensiveComparison({ comparison }: ComprehensiveComparisonProps) {
  const { platforms, bestPrice, bestRating, fastestDelivery, bestQuality, bestValue, recommended, recommendationReason } = comparison;

  // Generate badges for each platform
  const getPlatformBadges = (platform: PlatformComparison): string[] => {
    const badges: string[] = [];
    if (platform === bestPrice) badges.push("Lowest Price");
    if (platform === bestRating) badges.push("Highest Rated");
    if (platform === fastestDelivery) badges.push("Fastest Delivery");
    if (platform === bestQuality) badges.push("Best Quality");
    if (platform === bestValue) badges.push("Best Value");
    return badges;
  };

  return (
    <div className="space-y-6">
      {/* Recommendation Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Award className="h-5 w-5 text-blue-600" />
            <span>Smart Recommendation</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-lg">
            <strong>{recommended.platformName}</strong> is recommended because it offers the {recommendationReason}.
          </p>
        </CardContent>
      </Card>

      {/* Quick Comparison Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          icon={DollarSign}
          title="Best Price"
          value={`₹${bestPrice.price.toLocaleString()}`}
          description={`on ${bestPrice.platformName}`}
          color="green"
        />
        <MetricCard
          icon={Star}
          title="Highest Rating"
          value={`${bestRating.rating.toFixed(1)}/5`}
          description={`on ${bestRating.platformName}`}
          color="yellow"
        />
        <MetricCard
          icon={Clock}
          title="Fastest Delivery"
          value={`${fastestDelivery.deliveryTimeMin} days`}
          description={`via ${fastestDelivery.platformName}`}
          color="blue"
        />
        <MetricCard
          icon={Award}
          title="Best Quality"
          value={`${bestQuality.qualityRating.toFixed(1)}/5`}
          description={`on ${bestQuality.platformName}`}
          color="purple"
        />
      </div>

      {/* Detailed Platform Comparison */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Platform Overview</TabsTrigger>
          <TabsTrigger value="metrics">Detailed Metrics</TabsTrigger>
          <TabsTrigger value="policies">Policies & Service</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {platforms.map((platform) => (
              <PlatformCard
                key={platform.platformId}
                platform={platform}
                isRecommended={platform === recommended}
                badges={getPlatformBadges(platform)}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-4">
          <div className="space-y-6">
            {platforms.map((platform) => (
              <Card key={platform.platformId}>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <span style={{ color: platform.colorCode }}>{platform.platformName}</span>
                    {platform === recommended && (
                      <Badge variant="default">Recommended</Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {/* Price Score */}
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Price Competitiveness</span>
                        <span>{(platform.metrics.price * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={platform.metrics.price * 100} className="h-2" />
                    </div>

                    {/* Rating Score */}
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Customer Ratings</span>
                        <span>{(platform.metrics.rating * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={platform.metrics.rating * 100} className="h-2" />
                    </div>

                    {/* Delivery Score */}
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Delivery Speed</span>
                        <span>{(platform.metrics.delivery * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={platform.metrics.delivery * 100} className="h-2" />
                    </div>

                    {/* Quality Score */}
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Product Quality</span>
                        <span>{(platform.metrics.quality * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={platform.metrics.quality * 100} className="h-2" />
                    </div>

                    {/* Return Policy Score */}
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Return Policy</span>
                        <span>{(platform.metrics.returnPolicy * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={platform.metrics.returnPolicy * 100} className="h-2" />
                    </div>

                    {/* Value Score */}
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Value for Money</span>
                        <span>{(platform.metrics.valueForMoney * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={platform.metrics.valueForMoney * 100} className="h-2" />
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Overall Score */}
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Overall Score</span>
                      <span className="font-bold text-lg">{(platform.metrics.overallScore * 100).toFixed(0)}%</span>
                    </div>
                    <Progress value={platform.metrics.overallScore * 100} className="h-3" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="policies" className="space-y-4">
          <div className="grid gap-4">
            {platforms.map((platform) => (
              <Card key={platform.platformId}>
                <CardHeader>
                  <CardTitle style={{ color: platform.colorCode }}>
                    {platform.platformName}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Delivery & Shipping */}
                    <div className="space-y-3">
                      <h4 className="font-medium flex items-center space-x-2">
                        <Package className="h-4 w-4" />
                        <span>Delivery & Shipping</span>
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Delivery Time:</span>
                          <span>{platform.deliveryTimeMin}-{platform.deliveryTimeMax} days</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Shipping Cost:</span>
                          <span>{platform.shippingCost > 0 ? `₹${platform.shippingCost}` : 'Free'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Delivery Experience:</span>
                          <span className="flex items-center space-x-1">
                            <Star className="h-3 w-3 text-yellow-400 fill-current" />
                            <span>{platform.deliveryExperienceRating.toFixed(1)}/5</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Returns & Support */}
                    <div className="space-y-3">
                      <h4 className="font-medium flex items-center space-x-2">
                        <Shield className="h-4 w-4" />
                        <span>Returns & Support</span>
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Return Window:</span>
                          <span>{platform.returnPolicyDays} days</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Return Policy Rating:</span>
                          <span className="flex items-center space-x-1">
                            <Star className="h-3 w-3 text-yellow-400 fill-current" />
                            <span>{platform.returnPolicyRating.toFixed(1)}/5</span>
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Customer Service:</span>
                          <span className="flex items-center space-x-1">
                            <Star className="h-3 w-3 text-yellow-400 fill-current" />
                            <span>{platform.customerServiceRating.toFixed(1)}/5</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}