import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ProductWithPrices } from "@shared/schema";
import { useProducts } from "@/hooks/use-products";
import { Skeleton } from "@/components/ui/skeleton";
import { Icons } from "@/components/price-comparison";
import { Button } from "@/components/ui/button";

export default function TrendingDeals() {
  const { products, isLoading, error } = useProducts({
    limit: 3,
    sortBy: "discount",
  });

  // Find the best price for a product
  const getBestPrice = (product: ProductWithPrices) => {
    if (!product.prices || product.prices.length === 0) return null;
    
    return product.prices.reduce((min, price) => {
      const amount = typeof price.amount === 'string' ? parseFloat(price.amount) : price.amount;
      return amount < min.amount ? { amount, platform: price.platform } : min;
    }, { amount: Infinity, platform: null });
  };

  // Render loading state
  if (isLoading) {
    return (
      <div className="mt-16">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Trending Deals</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-5 w-16" />
                </div>
                <div className="space-y-2 mb-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                </div>
                <Skeleton className="h-9 w-full" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="mt-16">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Trending Deals</h2>
        <div className="bg-red-50 p-4 rounded-lg text-red-600 text-center">
          Failed to load trending deals
        </div>
      </div>
    );
  }

  return (
    <div className="mt-16">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Trending Deals</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {products.map((product) => {
          const bestDeal = getBestPrice(product);
          
          return (
            <div key={product.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition border border-gray-100 overflow-hidden">
              <div className="h-48 bg-gray-100 relative">
                <img 
                  src={product.imageUrl || "https://via.placeholder.com/300"} 
                  alt={product.name} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-medium px-2 py-1 rounded">
                  Save 25%
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-gray-900">{product.name}</h3>
                  <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Best Deal</div>
                </div>
                <div className="space-y-2 mb-3">
                  {product.prices.map((price) => (
                    <div key={price.id} className="flex items-center text-sm">
                      <span className="w-20 text-gray-500">{price.platform.name}</span>
                      <span className="font-semibold">
                        ₹{typeof price.amount === 'number' 
                          ? price.amount.toFixed(2) 
                          : parseFloat(price.amount).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
                <Link href={`/search?product=${product.slug}`}>
                  <Button className="w-full">View Comparison</Button>
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
