import { useState } from "react";
import { Link } from "wouter";
import { ProductWithPrices } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { PriceComparison, Icons } from "@/components/price-comparison";
import { cn } from "@/lib/utils";

type ProductCardProps = {
  product: ProductWithPrices;
  viewMode?: "grid" | "list";
  className?: string;
};

export default function ProductCard({ product, viewMode = "grid", className }: ProductCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  
  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  // Generate star rating
  const renderRating = (rating: number | string | null | undefined) => {
    if (!rating) return null;
    
    const numRating = typeof rating === 'string' ? parseFloat(rating) : rating;
    
    const stars = [];
    const fullStars = Math.floor(numRating);
    const hasHalfStar = numRating % 1 >= 0.5;
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Icons.StarFill key={`star-${i}`} className="text-yellow-400 h-3 w-3" />
      );
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(
        <Icons.StarHalf key="half-star" className="text-yellow-400 h-3 w-3" />
      );
    }
    
    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Icons.Star key={`empty-${i}`} className="text-yellow-400 h-3 w-3" />
      );
    }
    
    return (
      <div className="flex items-center mb-2">
        <div className="flex text-yellow-400 mr-1">
          {stars}
        </div>
        <span className="text-xs text-gray-500">({product.reviewCount || 0})</span>
      </div>
    );
  };

  return (
    <div className={cn(
      "bg-white rounded-xl shadow-sm hover:shadow-md transition border border-gray-100 overflow-hidden",
      viewMode === "list" ? "flex flex-col md:flex-row" : "",
      className
    )}>
      <div className={cn(
        "relative",
        viewMode === "list" ? "md:w-1/3" : ""
      )}>
        <img 
          src={product.imageUrl || "https://via.placeholder.com/300"} 
          alt={product.name} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-white rounded-full p-1.5 shadow-sm">
          <button 
            className={`focus:outline-none ${isFavorite ? 'text-red-500' : 'text-gray-400 hover:text-primary'}`}
            onClick={toggleFavorite}
          >
            {isFavorite ? (
              <Icons.HeartFill className="h-5 w-5" />
            ) : (
              <Icons.Heart className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>
      <div className={cn(
        "p-4",
        viewMode === "list" ? "md:w-2/3" : ""
      )}>
        <div className="flex justify-between items-start mb-1">
          <div>
            <h3 className="font-medium text-gray-900 mb-1">{product.name}</h3>
            {renderRating(product.rating)}
          </div>
        </div>
        
        <PriceComparison prices={product.prices} className="mb-4" />
        
        <div>
          <Button className="w-full" asChild>
            <Link href={`/product/${product.slug}`}>
              View Full Comparison
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
