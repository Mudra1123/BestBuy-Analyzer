import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Icons } from "@/components/price-comparison";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
  initialValue?: string;
  className?: string;
}

export default function SearchBar({ onSearch, placeholder = "Search...", initialValue = "", className }: SearchBarProps) {
  const [query, setQuery] = useState(initialValue);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setQuery(initialValue);
  }, [initialValue]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSubmit(e);
    }
  };

  return (
    <div className={cn("relative search-animation", className)}>
      <form onSubmit={handleSubmit} className="relative">
        <Input
          ref={searchInputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full py-4 px-5 pr-12 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary/20 shadow-sm"
        />
        <Button
          type="submit"
          className="absolute right-3 top-1/2 -translate-y-1/2 bg-primary text-white p-2 h-auto rounded-full hover:bg-primary/90 transition"
        >
          <Icons.Search className="h-5 w-5" />
        </Button>
      </form>
    </div>
  );
}
