import { useState } from "react";
import { WebSocketMessage } from "@/store/types";
import { Price } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { apiRequest } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowDown, ArrowUp, RefreshCw, ShoppingCart, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

interface RealTimePriceComparisonProps {
  productId: number;
  initialPrices: Price[];
  className?: string;
}

export default function RealTimePriceComparison({
  productId,
  initialPrices,
  className,
}: RealTimePriceComparisonProps) {
  const [prices, setPrices] = useState<Price[]>(initialPrices);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const { toast } = useToast();

  // Track price changes for animation effects
  const [priceChanges, setPriceChanges] = useState<Record<number, "up" | "down" | null>>({});
  
  // WebSocket connection for real-time updates
  const { lastMessage } = useWebSocket({
    onMessage: (event) => {
      try {
        const data = JSON.parse(event.data) as WebSocketMessage;
        
        if (data.type === "PRICE_UPDATE" && data.payload.productId === productId) {
          // Update the price in our local state
          setPrices(currentPrices => 
            currentPrices.map(price => {
              if (price.platformId === data.payload.platformId) {
                // Track price change direction for animation
                const changeDirection = 
                  data.payload.newPrice > data.payload.oldPrice ? "up" : "down";
                
                setPriceChanges(prev => ({
                  ...prev,
                  [price.platformId]: changeDirection
                }));
                
                // Clear price change animation after 2 seconds
                setTimeout(() => {
                  setPriceChanges(prev => ({
                    ...prev,
                    [price.platformId]: null
                  }));
                }, 2000);
                
                return {
                  ...price,
                  amount: data.payload.newPrice,
                  lastUpdated: new Date(data.payload.timestamp)
                };
              }
              return price;
            })
          );
          
          setLastUpdated(new Date(data.payload.timestamp));
          
          toast({
            title: "Price Updated",
            description: `Price for this product on ${data.payload.platformId} has been updated.`,
            variant: "default",
          });
        }
        
        if (data.type === "PRICE_REFRESH_COMPLETE" && 
            data.payload.updatedProductIds.includes(productId)) {
          setLastUpdated(new Date(data.payload.timestamp));
          setRefreshing(false);
          
          toast({
            title: "Prices Refreshed",
            description: "All prices for this product have been refreshed.",
            variant: "default",
          });
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    }
  });
  
  // Sort prices by amount (lowest first)
  const sortedPrices = [...prices].sort((a, b) => {
    const amountA = typeof a.amount === 'number' ? a.amount : parseFloat(a.amount.toString());
    const amountB = typeof b.amount === 'number' ? b.amount : parseFloat(b.amount.toString());
    return amountA - amountB;
  });
  
  // Find the best price
  const bestPrice = sortedPrices[0];
  
  // Format price nicely
  const formatPrice = (amount: number | string) => {
    const numericAmount = typeof amount === 'number' ? amount : parseFloat(amount.toString());
    
    // Format based on size of the amount
    if (numericAmount >= 1000) {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(numericAmount);
    } else {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(numericAmount);
    }
  };
  
  // Manually refresh prices from the API
  const handleRefresh = async () => {
    setRefreshing(true);
    
    try {
      const response = await apiRequest({
        method: "POST",
        url: `/api/products/${productId}/refresh-price`,
      });
      
      // If we don't receive a WebSocket update within 5 seconds, stop the refreshing indicator
      setTimeout(() => {
        setRefreshing(false);
      }, 5000);
      
    } catch (error) {
      console.error("Error refreshing prices:", error);
      toast({
        title: "Error",
        description: "Failed to refresh prices. Please try again.",
        variant: "destructive",
      });
      setRefreshing(false);
    }
  };
  
  // Calculate time since last update
  const getTimeSinceUpdate = () => {
    const now = new Date();
    const diffMs = now.getTime() - lastUpdated.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins === 1) return "1 minute ago";
    if (diffMins < 60) return `${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours === 1) return "1 hour ago";
    if (diffHours < 24) return `${diffHours} hours ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays === 1) return "1 day ago";
    return `${diffDays} days ago`;
  };

  // Get platform information from database - this is a placeholder since we don't have
  // the actual platform data from the database (the platform relation isn't included in Price type)
  // In a real app, we would fetch this data or ensure it's included in the initial data
  const platformData = [
    {
      id: 1,
      name: "Amazon",
      logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/320px-Amazon_logo.svg.png",
      colorCode: "#FF9900"
    },
    {
      id: 2,
      name: "Flipkart",
      logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Flipkart_logo.svg/320px-Flipkart_logo.svg.png",
      colorCode: "#2874f0"
    },
    {
      id: 3,
      name: "Myntra",
      logoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Myntra_logo.png/320px-Myntra_logo.png",
      colorCode: "#ff3f6c"
    }
  ];

  // Get platform by ID from our local array
  const getPlatformById = (id: number) => {
    const platform = platformData.find(p => p.id === id);
    return platform || { id, name: `Platform ${id}`, logoUrl: "", colorCode: "#555" };
  };
  
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl">Price Comparison</CardTitle>
            <CardDescription>
              Updated {getTimeSinceUpdate()}
            </CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw 
              className={cn("h-4 w-4 mr-2", refreshing && "animate-spin")} 
            />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y">
          {sortedPrices.map((price, index) => {
            const isBestPrice = index === 0;
            const changeDirection = priceChanges[price.platformId];
            const platform = getPlatformById(price.platformId);
            
            return (
              <div 
                key={price.platformId}
                className={cn(
                  "flex items-center justify-between p-4",
                  isBestPrice && "bg-green-50 dark:bg-green-950",
                  changeDirection === "up" && "animate-pulse bg-red-50 dark:bg-red-950",
                  changeDirection === "down" && "animate-pulse bg-green-50 dark:bg-green-950"
                )}
              >
                <div className="flex items-center gap-3">
                  {platform.logoUrl && (
                    <div className="h-8 w-8 shrink-0 overflow-hidden rounded">
                      <img 
                        src={platform.logoUrl} 
                        alt={platform.name} 
                        className="h-full w-full object-contain"
                      />
                    </div>
                  )}
                  <div>
                    <h3 className="font-medium">{platform.name}</h3>
                    {price.isAvailable ? (
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline" 
                          className="text-xs font-normal bg-white dark:bg-gray-800"
                        >
                          In Stock
                        </Badge>
                        
                        {isBestPrice && (
                          <Badge 
                            className="bg-green-500 text-white hover:bg-green-600 text-xs"
                          >
                            Best Price
                          </Badge>
                        )}
                      </div>
                    ) : (
                      <Badge 
                        variant="outline"
                        className="text-xs font-normal text-gray-500 border-gray-300"
                      >
                        Out of Stock
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="flex flex-col items-end">
                  <div className="flex items-center">
                    {changeDirection === "up" && (
                      <ArrowUp className="h-4 w-4 text-red-600 mr-1" />
                    )}
                    {changeDirection === "down" && (
                      <ArrowDown className="h-4 w-4 text-green-600 mr-1" />
                    )}
                    <span 
                      className={cn(
                        "text-xl font-bold", 
                        isBestPrice && "text-green-600 dark:text-green-400",
                        changeDirection === "up" && "text-red-600",
                        changeDirection === "down" && "text-green-600"
                      )}
                    >
                      {formatPrice(price.amount)}
                    </span>
                  </div>
                  
                  <div className="flex mt-2 gap-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="h-8 px-2 text-xs"
                      asChild
                    >
                      <a href={price.url || "#"} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        View
                      </a>
                    </Button>
                    
                    <Button 
                      size="sm" 
                      className={cn(
                        "h-8 px-2 text-xs",
                        platform.colorCode && {
                          backgroundColor: platform.colorCode,
                          borderColor: platform.colorCode,
                          color: "#fff",
                          "&:hover": {
                            backgroundColor: platform.colorCode,
                            opacity: 0.9,
                          },
                        }
                      )}
                      style={{
                        backgroundColor: platform.colorCode || undefined,
                        borderColor: platform.colorCode || undefined,
                      }}
                      asChild
                    >
                      <a href={price.url || "#"} target="_blank" rel="noopener noreferrer">
                        <ShoppingCart className="h-3 w-3 mr-1" />
                        Buy Now
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}