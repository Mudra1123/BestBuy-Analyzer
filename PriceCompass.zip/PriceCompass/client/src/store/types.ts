import { ProductWithPrices, Category, Brand, Gender, Size, Platform, Price } from "@shared/schema";

// Re-export schema types for use in components
export type { ProductWithPrices, Category, Brand, Gender, Size, Platform, Price };

// API Response Types
export interface ApiResponse<T> {
  data: T;
  message?: string;
  status: 'success' | 'error';
}

export interface ProductsResponse {
  products: ProductWithPrices[];
  total: number;
  page: number;
  limit: number;
}

export interface CategoriesResponse {
  categories: Category[];
}

export interface BrandsResponse {
  brands: Brand[];
}

export interface GendersResponse {
  genders: Gender[];
}

export interface SizesResponse {
  sizes: Size[];
}

export interface PlatformsResponse {
  platforms: Platform[];
}

// Filter Types
export interface ProductFilters {
  categories?: string[];
  brands?: string[];
  genders?: string[];
  sizes?: string[];
  priceRange?: [number, number];
  searchQuery?: string;
  sortBy?: string;
  page?: number;
  limit?: number;
}

// WebSocket Message Types
export type WebSocketMessageType = 
  | 'PRICE_UPDATE'
  | 'REFRESH_PRICES'
  | 'PRICE_REFRESH_COMPLETE';

export interface WebSocketMessage {
  type: WebSocketMessageType;
  payload?: any;
}

export interface PriceUpdateMessage extends WebSocketMessage {
  type: 'PRICE_UPDATE';
  payload: {
    productId: number;
    platformId: number;
    oldPrice: number;
    newPrice: number;
    timestamp: string;
  };
}

export interface PriceRefreshCompleteMessage extends WebSocketMessage {
  type: 'PRICE_REFRESH_COMPLETE';
  payload: {
    timestamp: string;
    updatedProductIds: number[];
  };
}
